from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, sanitize_predictions
from models.registry_types import ModelSpec

try:
    from models.foundation import config
except Exception:
    config = None


class Chronos2Forecaster(BaseForecaster):
    """Zero-shot Chronos-2 forecaster.

    This wrapper follows the same BaseForecaster interface as your other models:

        fit(y, horizon, context)
            Stores the observed history only.

        predict(n_steps)
            Runs zero-shot Chronos-2 inference.

    Chronos-2 expects a pandas DataFrame with:
        item_id, timestamp, target

    Since your evaluator gives only a univariate numpy array, we create synthetic
    timestamps. The chosen frequency can be controlled with freq/context/config.
    """

    _PIPELINE_CACHE: Dict[Tuple[str, str, str], object] = {}

    def __init__(
        self,
        model_id: str = "amazon/chronos-2",
        model_name: str = "Chronos2",
        device_map: str = "cuda",
        torch_dtype: str = "auto",
        quantile: float = 0.5,
        freq: str = "D",
        context_length: Optional[int] = None,
        debug: bool = False,
    ):
        self.model_id = str(model_id)
        self.name = str(model_name)
        self.device_map = str(device_map)
        self.torch_dtype = str(torch_dtype)
        self.quantile = float(quantile)
        self.freq = str(freq)
        self.context_length = context_length if context_length is None else int(context_length)
        self.debug = bool(debug)

        self.y_ = np.asarray([], dtype=float)
        self.freq_ = self.freq
        self.error_: Optional[str] = None

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[dict] = None):
        self.y_ = as_1d_float(y)
        self.error_ = None

        # Optional evaluator metadata support.
        # If your context contains a frequency, Chronos-2 can use it.
        if isinstance(context, dict):
            freq = (
                context.get("freq")
                or context.get("frequency")
                or context.get("pandas_freq")
            )
            if freq is not None:
                self.freq_ = str(freq)
            else:
                self.freq_ = self.freq
        else:
            self.freq_ = self.freq

        return self

    def _resolve_device_map(self):
        if self.device_map != "auto":
            return self.device_map

        import torch

        if torch.cuda.is_available():
            return "cuda"

        return "cpu"

    def _resolve_torch_dtype(self):
        import torch

        if self.torch_dtype == "float32":
            return torch.float32

        if self.torch_dtype == "float16":
            return torch.float16

        if self.torch_dtype == "bfloat16":
            return torch.bfloat16

        # Auto dtype.
        device_map = self._resolve_device_map()

        if device_map == "cuda":
            return torch.bfloat16

        return torch.float32

    def _load_pipeline(self):
        device_map = self._resolve_device_map()
        torch_dtype = self._resolve_torch_dtype()

        cache_key = (
            self.model_id,
            str(device_map),
            str(torch_dtype),
        )

        if cache_key in self._PIPELINE_CACHE:
            return self._PIPELINE_CACHE[cache_key]

        try:
            from chronos import BaseChronosPipeline
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "Chronos is not installed. Install/update with:\n"
                'python -m pip install "chronos-forecasting[extras]>=2.2"'
            ) from exc

        if self.debug:
            print(
                f"[Chronos2] loading {self.model_id} "
                f"device_map={device_map}, torch_dtype={torch_dtype}"
            )

        pipeline = BaseChronosPipeline.from_pretrained(
            self.model_id,
            device_map=device_map,
            torch_dtype=torch_dtype,
        )

        self._PIPELINE_CACHE[cache_key] = pipeline
        return pipeline

    def _make_context_df(self, y: np.ndarray):
        import pandas as pd

        if self.context_length is not None and self.context_length > 0:
            y = y[-self.context_length :]

        # Synthetic timestamps because the current BaseForecaster interface only
        # passes values. Frequency still matters, so expose self.freq_.
        timestamps = pd.date_range(
            start="2000-01-01",
            periods=len(y),
            freq=self.freq_,
        )

        return pd.DataFrame(
            {
                "item_id": "series_0",
                "timestamp": timestamps,
                "target": y.astype(float),
            }
        )

    def _extract_prediction_array(self, pred_df, n_steps: int) -> np.ndarray:
        df = pred_df.copy()

        # Keep our single series if the output contains identifiers.
        if "item_id" in df.columns:
            df = df[df["item_id"] == "series_0"]

        # Keep our target if Chronos-2 returns target_name.
        if "target_name" in df.columns:
            df = df[df["target_name"] == "target"]

        if "timestamp" in df.columns:
            df = df.sort_values("timestamp")

        q_col_candidates = [
            f"{self.quantile:g}",
            str(self.quantile),
            self.quantile,
        ]

        for col in q_col_candidates:
            if col in df.columns:
                return df[col].to_numpy(dtype=float)[:n_steps]

        # In the official Chronos-2 output, "predictions" is the point forecast.
        if "predictions" in df.columns:
            return df["predictions"].to_numpy(dtype=float)[:n_steps]

        # Last-resort numeric-column fallback.
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

        # Avoid accidentally selecting identifiers if present.
        numeric_cols = [
            c for c in numeric_cols
            if str(c) not in {"item_id"}
        ]

        if numeric_cols:
            return df[numeric_cols[-1]].to_numpy(dtype=float)[:n_steps]

        raise ValueError(
            f"Could not find prediction column in Chronos-2 output. "
            f"Columns were: {list(pred_df.columns)}"
        )

    def predict(self, n_steps: int) -> np.ndarray:
        n_steps = int(n_steps)

        fallback = float(self.y_[-1]) if len(self.y_) else 0.0

        if n_steps <= 0:
            return np.asarray([], dtype=float)

        if len(self.y_) == 0:
            return np.repeat(fallback, n_steps)

        try:
            pipeline = self._load_pipeline()

            y = np.asarray(self.y_, dtype=np.float32)
            y = y[np.isfinite(y)]

            if len(y) == 0:
                return np.repeat(fallback, n_steps)

            context_df = self._make_context_df(y)

            pred_df = pipeline.predict_df(
                context_df,
                prediction_length=n_steps,
                quantile_levels=[self.quantile],
                id_column="item_id",
                timestamp_column="timestamp",
                target="target",
            )

            pred = self._extract_prediction_array(pred_df, n_steps=n_steps)

        except Exception as exc:
            self.error_ = str(exc)

            if self.debug:
                print(f"[Chronos2] prediction failed: {exc}")

            pred = np.repeat(fallback, n_steps)

        return sanitize_predictions(
            pred,
            fallback_value=fallback,
            n_steps=n_steps,
        )


def get_model_specs() -> List[ModelSpec]:
    if config is None:
        return []

    if not bool(getattr(config, "CHRONOS2_ENABLED", False)):
        return []

    def factory() -> BaseForecaster:
        return Chronos2Forecaster(
            model_id=getattr(config, "CHRONOS2_MODEL_ID", "amazon/chronos-2"),
            model_name=getattr(config, "CHRONOS2_MODEL_NAME", "Chronos2"),
            device_map=getattr(config, "CHRONOS2_DEVICE_MAP", "cuda"),
            torch_dtype=getattr(config, "CHRONOS2_TORCH_DTYPE", "auto"),
            quantile=getattr(config, "CHRONOS2_QUANTILE", 0.5),
            freq=getattr(config, "CHRONOS2_FREQ", "D"),
            context_length=getattr(config, "CHRONOS2_CONTEXT_LENGTH", None),
            debug=getattr(config, "DEBUG", False),
        )

    return [
        ModelSpec(
            name=getattr(config, "CHRONOS2_MODEL_NAME", "Chronos2"),
            factory=factory,
        )
    ]