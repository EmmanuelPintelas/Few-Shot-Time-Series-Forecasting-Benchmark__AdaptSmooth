"""Foundation model configuration."""

CHRONOS_ENABLED = False
CHRONOS_MODEL_NAME = "ChronosBolt_Mini"  #"ChronosBolt_Tiny"
CHRONOS_MODEL_ID = "amazon/chronos-bolt-mini"   #"amazon/chronos-bolt-tiny"
# Use "auto", "cpu", or "cuda".
CHRONOS_DEVICE_MAP = "auto"
# Use "auto", "float32", "float16", or "bfloat16".
CHRONOS_TORCH_DTYPE = "auto"
# Median forecast.
CHRONOS_QUANTILE = 0.5
#------------------------------------------
CHRONOS2_ENABLED = True

CHRONOS2_MODEL_NAME = "Chronos2"
CHRONOS2_MODEL_ID = "amazon/chronos-2"

CHRONOS2_DEVICE_MAP = "cuda"
CHRONOS2_TORCH_DTYPE = "auto"

CHRONOS2_QUANTILE = 0.5
CHRONOS2_FREQ = "D"

# Optional. None means use all available history.
# Chronos-2 max context is larger than Bolt, but limiting can speed evaluation.
CHRONOS2_CONTEXT_LENGTH = None


DEBUG = False