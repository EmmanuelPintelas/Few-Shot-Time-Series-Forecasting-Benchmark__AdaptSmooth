from __future__ import annotations

from typing import Dict, Optional, Tuple
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, sanitize_predictions


class ChronosForecaster(BaseForecaster):
    """Zero-shot Chronos / Chronos-Bolt forecaster.

    Recommended starting model:
        amazon/chronos-bolt-tiny

    This model does not train on the current task. fit() only stores the
    observed history; predict() runs zero-shot inference.
    """

    _PIPELINE_CACHE: Dict[Tuple[str, str, str], object] = {}

    def __init__(
        self,
        model_id: str = "amazon/chronos-bolt-tiny",
        model_name: str = "ChronosBolt_Tiny",
        device_map: str = "auto",
        torch_dtype: str = "auto",
        quantile: float = 0.5,
        fallback_to_mean: bool = True,
        debug: bool = False,
    ):
        self.model_id = str(model_id)
        self.name = str(model_name)
        self.device_map = str(device_map)
        self.torch_dtype = str(torch_dtype)
        self.quantile = float(quantile)
        self.fallback_to_mean = bool(fallback_to_mean)
        self.debug = bool(debug)

        self.y_ = np.asarray([], dtype=float)
        self.error_: Optional[str] = None

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[dict] = None):
        self.y_ = as_1d_float(y)
        self.error_ = None
        return self

    def _resolve_device_map(self):
        if self.device_map != "auto":
            return self.device_map

        import torch

        if torch.cuda.is_available():
            return "cuda"

        # Keep simple for Windows / CPU environments.
        return "cpu"

    def _resolve_torch_dtype(self):
        import torch

        if self.torch_dtype == "float32":
            return torch.float32

        if self.torch_dtype == "float16":
            return torch.float16

        if self.torch_dtype == "bfloat16":
            return torch.bfloat16

        # Auto dtype.
        device_map = self._resolve_device_map()

        if device_map == "cuda":
            return torch.bfloat16

        return torch.float32

    def _load_pipeline(self):
        device_map = self._resolve_device_map()
        torch_dtype = self._resolve_torch_dtype()

        cache_key = (
            self.model_id,
            str(device_map),
            str(torch_dtype),
        )

        if cache_key in self._PIPELINE_CACHE:
            return self._PIPELINE_CACHE[cache_key]

        try:
            from chronos import BaseChronosPipeline
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "Chronos is not installed. Install it with:\n"
                'python -m pip install "chronos-forecasting>=1.5.0" accelerate'
            ) from exc

        if self.debug:
            print(
                f"[Chronos] loading {self.model_id} "
                f"on device_map={device_map}, torch_dtype={torch_dtype}"
            )

        pipeline = BaseChronosPipeline.from_pretrained(
            self.model_id,
            device_map=device_map,
            torch_dtype=torch_dtype,
        )

        self._PIPELINE_CACHE[cache_key] = pipeline
        return pipeline

    def predict(self, n_steps: int) -> np.ndarray:
        n_steps = int(n_steps)

        fallback = float(self.y_[-1]) if len(self.y_) else 0.0

        if n_steps <= 0:
            return np.asarray([], dtype=float)

        if len(self.y_) == 0:
            return np.repeat(fallback, n_steps)

        try:
            import torch

            pipeline = self._load_pipeline()

            y = np.asarray(self.y_, dtype=np.float32)
            y = y[np.isfinite(y)]

            if len(y) == 0:
                return np.repeat(fallback, n_steps)

            context_tensor = torch.tensor(y, dtype=torch.float32)

            # Preferred for Chronos-Bolt and newer Chronos pipelines.
            if hasattr(pipeline, "predict_quantiles"):
                quantiles, mean = pipeline.predict_quantiles(
                    inputs=context_tensor,
                    prediction_length=n_steps,
                    quantile_levels=[self.quantile],
                )

                pred = quantiles[0, :, 0].detach().cpu().numpy().astype(float)

                if self.fallback_to_mean and (
                    len(pred) != n_steps or not np.isfinite(pred).all()
                ):
                    pred = mean[0].detach().cpu().numpy().astype(float)

            else:
                # Fallback for older original Chronos-style sampling APIs.
                samples = pipeline.predict(
                    context_tensor,
                    prediction_length=n_steps,
                )

                samples_np = samples.detach().cpu().numpy().astype(float)

                # Expected original shape: [batch, samples, horizon]
                if samples_np.ndim == 3:
                    pred = np.median(samples_np[0], axis=0)
                else:
                    pred = np.asarray(samples_np).reshape(-1)[-n_steps:]

        except Exception as exc:
            self.error_ = str(exc)

            if self.debug:
                print(f"[Chronos] prediction failed: {exc}")

            pred = np.repeat(fallback, n_steps)

        return sanitize_predictions(
            pred,
            fallback_value=fallback,
            n_steps=n_steps,
        )
    
from typing import List

from models.base import BaseForecaster
from models.registry_types import ModelSpec
from models.foundation.chronos import ChronosForecaster
from models.foundation import config


def get_model_specs() -> List[ModelSpec]:
    if not config.CHRONOS_ENABLED:
        return []

    def factory() -> BaseForecaster:
        return ChronosForecaster(
            model_id=config.CHRONOS_MODEL_ID,
            model_name=config.CHRONOS_MODEL_NAME,
            device_map=config.CHRONOS_DEVICE_MAP,
            torch_dtype=config.CHRONOS_TORCH_DTYPE,
            quantile=config.CHRONOS_QUANTILE,
            debug=config.DEBUG,
        )

    return [
        ModelSpec(
            name=config.CHRONOS_MODEL_NAME,
            factory=factory,
        )
    ]
    
