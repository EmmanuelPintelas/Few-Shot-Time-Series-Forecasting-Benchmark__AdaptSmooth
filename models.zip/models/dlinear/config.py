"""Configuration for the local DLinear competitor.

DLinear is a simple decomposition-linear architecture. In this benchmark it is
trained from scratch on the currently available few-shot prefix at each online
origin, with no external pretraining.
"""

# Enable/disable all DLinear variants exposed by models/dlinear/dlinear.py.
ENABLE_DLINEAR = True

# One model is created for each input length in this list.
# Short lengths are safer for few-shot supports as small as 10 timestamps.
DLINEAR_INPUT_LENGTHS = [5]

# Moving-average kernel used for trend extraction. Must be odd; even values are
# automatically rounded up inside the model.
DLINEAR_MOVING_AVG_KERNEL = 3

# Training settings.
DLINEAR_EPOCHS = 20
DLINEAR_LR = 0.01
DLINEAR_WEIGHT_DECAY = 1e-4
DLINEAR_PATIENCE = 10
DLINEAR_MIN_TRAIN_WINDOWS = 3

# Refit policy. If 0 or 1, retrain at every online origin. If 50, retrain only
# after 50 newly revealed observations since the last successful refit.
DLINEAR_REFIT_EVERY_NEW_POINTS = 10

# Device. Use "auto" to select CUDA when available, otherwise CPU.
DLINEAR_DEVICE = "auto"

# Reproducibility.
DLINEAR_SEED = 42

# Print per-fit diagnostics. Useful for debugging; disable for final runs.
DLINEAR_DEBUG = False
