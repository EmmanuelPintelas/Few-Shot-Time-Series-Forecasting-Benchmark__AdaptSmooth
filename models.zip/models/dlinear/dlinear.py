from __future__ import annotations

from typing import Dict, List, Optional
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, is_constant, fallback_last, sanitize_predictions
from models.registry_types import ModelSpec
from models.dlinear import config

try:
    import torch
    import torch.nn as nn
except Exception:  # pragma: no cover
    torch = None
    nn = None


class LocalDLinearForecaster(BaseForecaster):
    """Local-from-scratch DLinear baseline.

    DLinear decomposes an input window into a moving-average trend component
    and a residual/seasonal component, then maps each component linearly to the
    forecast horizon. The two forecasts are added.

    This implementation is intentionally local: it trains only on the currently
    observed prefix supplied by the evaluator. It is therefore a strict
    few-shot, no-pretraining neural/linear baseline.
    """

    def __init__(
        self,
        input_length: int = 5,
        moving_avg_kernel: int = 3,
        epochs: int = 80,
        lr: float = 0.01,
        weight_decay: float = 1e-4,
        patience: int = 10,
        min_train_windows: int = 3,
        refit_every_new_points: int = 1,
        device: str = "auto",
        seed: int = 42,
        debug: bool = False,
    ):
        self.input_length = int(input_length)
        self.moving_avg_kernel = int(moving_avg_kernel)
        if self.moving_avg_kernel < 1:
            self.moving_avg_kernel = 1
        if self.moving_avg_kernel % 2 == 0:
            self.moving_avg_kernel += 1

        self.epochs = int(epochs)
        self.lr = float(lr)
        self.weight_decay = float(weight_decay)
        self.patience = int(patience)
        self.min_train_windows = int(min_train_windows)
        self.refit_every_new_points = int(refit_every_new_points)
        self.device_setting = str(device)
        self.seed = int(seed)
        self.debug = bool(debug)

        self.name = (
            f"LocalDLinear_L{self.input_length}"
            f"_K{self.moving_avg_kernel}"
            f"_ep{self.epochs}"
        )

        self.y_ = np.asarray([], dtype=float)
        self.model_ = None
        self.output_horizon_ = 1
        self.mu_ = 0.0
        self.scale_ = 1.0
        self.last_refit_n_ = 0
        self.n_refits_ = 0
        self.n_skips_ = 0
        self.n_failures_ = 0
        self.error_ = None

    class _DLinearTorchModel(nn.Module):
        def __init__(self, input_length: int, output_horizon: int, kernel_size: int):
            super().__init__()
            self.input_length = int(input_length)
            self.output_horizon = int(output_horizon)
            self.kernel_size = int(kernel_size)

            self.trend_linear = nn.Linear(self.input_length, self.output_horizon)
            self.seasonal_linear = nn.Linear(self.input_length, self.output_horizon)

            # DLinear-style initialization: close to averaging at the start.
            with torch.no_grad():
                self.trend_linear.weight.fill_(1.0 / self.input_length)
                self.seasonal_linear.weight.fill_(1.0 / self.input_length)
                self.trend_linear.bias.zero_()
                self.seasonal_linear.bias.zero_()

        def moving_average(self, x: torch.Tensor) -> torch.Tensor:
            """Replicate-padded moving average.

            x shape: [batch, input_length]
            returns shape: [batch, input_length]
            """
            if self.kernel_size <= 1:
                return x

            pad_left = (self.kernel_size - 1) // 2
            pad_right = self.kernel_size - 1 - pad_left

            left = x[:, :1].repeat(1, pad_left)
            right = x[:, -1:].repeat(1, pad_right)
            x_pad = torch.cat([left, x, right], dim=1)

            # avg_pool1d expects [batch, channels, length].
            trend = torch.nn.functional.avg_pool1d(
                x_pad.unsqueeze(1),
                kernel_size=self.kernel_size,
                stride=1,
            ).squeeze(1)
            return trend

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            trend = self.moving_average(x)
            seasonal = x - trend
            return self.trend_linear(trend) + self.seasonal_linear(seasonal)

    def _resolve_device(self) -> str:
        if torch is None:
            return "cpu"
        if self.device_setting == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        if self.device_setting == "cuda" and not torch.cuda.is_available():
            return "cpu"
        return self.device_setting

    def _make_xy(self, y: np.ndarray, horizon: int):
        X, target = [], []
        L = self.input_length
        H = int(horizon)

        max_start = len(y) - L - H + 1
        if max_start <= 0:
            return None, None

        for start in range(max_start):
            X.append(y[start:start + L])
            target.append(y[start + L:start + L + H])

        if not X:
            return None, None

        return np.asarray(X, dtype=float), np.asarray(target, dtype=float)

    def _should_refit(self, n_obs: int) -> bool:
        if self.model_ is None:
            return True
        if self.refit_every_new_points <= 1:
            return True
        return (n_obs - self.last_refit_n_) >= self.refit_every_new_points

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        self.error_ = None
        self.output_horizon_ = max(1, int(horizon))

        if torch is None or nn is None:
            self.model_ = None
            self.error_ = "PyTorch is not installed"
            return self

        if len(self.y_) < self.input_length + self.output_horizon_ or is_constant(self.y_):
            self.error_ = "too short or constant"
            return self

        if not self._should_refit(len(self.y_)):
            self.n_skips_ += 1
            return self

        X, target = self._make_xy(self.y_, self.output_horizon_)
        if X is None or len(X) < self.min_train_windows:
            self.model_ = None
            self.error_ = "not enough training windows"
            return self

        try:
            torch.manual_seed(self.seed)
            np.random.seed(self.seed)

            self.mu_ = float(np.mean(self.y_))
            self.scale_ = float(np.std(self.y_))
            if not np.isfinite(self.scale_) or self.scale_ < 1e-8:
                self.scale_ = 1.0

            X_scaled = (X - self.mu_) / self.scale_
            target_scaled = (target - self.mu_) / self.scale_

            device = self._resolve_device()
            X_tensor = torch.tensor(X_scaled, dtype=torch.float32, device=device)
            y_tensor = torch.tensor(target_scaled, dtype=torch.float32, device=device)

            model = self._DLinearTorchModel(
                input_length=self.input_length,
                output_horizon=self.output_horizon_,
                kernel_size=self.moving_avg_kernel,
            ).to(device)

            optimizer = torch.optim.Adam(
                model.parameters(),
                lr=self.lr,
                weight_decay=self.weight_decay,
            )
            loss_fn = nn.MSELoss()

            best_loss = float("inf")
            best_state = None
            bad_epochs = 0

            model.train()
            for _ in range(self.epochs):
                optimizer.zero_grad(set_to_none=True)
                pred = model(X_tensor)
                loss = loss_fn(pred, y_tensor)

                if not torch.isfinite(loss):
                    self.model_ = None
                    self.error_ = "non-finite loss"
                    return self

                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()

                loss_value = float(loss.detach().cpu())
                if loss_value + 1e-8 < best_loss:
                    best_loss = loss_value
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                    bad_epochs = 0
                else:
                    bad_epochs += 1

                if bad_epochs >= self.patience:
                    break

            if best_state is not None:
                model.load_state_dict(best_state)

            model.eval()
            self.model_ = model
            self.device_ = device
            self.last_refit_n_ = len(self.y_)
            self.n_refits_ += 1

            if self.debug:
                print(
                    f"[DLinear FIT] n={len(self.y_)}, L={self.input_length}, "
                    f"H={self.output_horizon_}, windows={len(X)}, "
                    f"device={device}, loss={best_loss:.6f}"
                )

        except Exception as exc:
            self.model_ = None
            self.error_ = repr(exc)
            self.n_failures_ += 1
            if self.debug:
                print(f"[DLinear ERROR] {self.error_}")

        return self

    def _predict_direct(self, n_steps: int) -> Optional[np.ndarray]:
        if self.model_ is None or torch is None:
            return None
        if len(self.y_) < self.input_length:
            return None

        device = getattr(self, "device_", self._resolve_device())
        x = self.y_[-self.input_length:]
        x_scaled = (x - self.mu_) / self.scale_

        with torch.no_grad():
            x_tensor = torch.tensor(x_scaled.reshape(1, -1), dtype=torch.float32, device=device)
            pred_scaled = self.model_(x_tensor).detach().cpu().numpy().reshape(-1)

        pred = self.mu_ + self.scale_ * pred_scaled
        return pred[:n_steps]

    def predict(self, n_steps: int) -> np.ndarray:
        if len(self.y_) == 0:
            return np.zeros(n_steps, dtype=float)
        if self.model_ is None:
            return fallback_last(self.y_, n_steps)

        try:
            # Direct case, which is the usual evaluator call when n_steps == horizon.
            if n_steps <= self.output_horizon_:
                pred = self._predict_direct(n_steps)
                if pred is None or len(pred) != n_steps:
                    return fallback_last(self.y_, n_steps)
                return sanitize_predictions(pred, fallback_value=float(self.y_[-1]), n_steps=n_steps)

            # Rare case: requested n_steps is longer than trained horizon. Roll forward.
            hist = self.y_.copy()
            preds = []
            while len(preds) < n_steps:
                old_y = self.y_
                self.y_ = hist
                block = self._predict_direct(min(self.output_horizon_, n_steps - len(preds)))
                self.y_ = old_y
                if block is None or len(block) == 0:
                    break
                preds.extend(block.tolist())
                hist = np.concatenate([hist, np.asarray(block, dtype=float)])

            if len(preds) != n_steps:
                return fallback_last(self.y_, n_steps)

            return sanitize_predictions(
                np.asarray(preds, dtype=float),
                fallback_value=float(self.y_[-1]),
                n_steps=n_steps,
            )

        except Exception:
            return fallback_last(self.y_, n_steps)


def get_model_specs() -> List[ModelSpec]:
    if not config.ENABLE_DLINEAR:
        return []

    specs: List[ModelSpec] = []
    for input_length in config.DLINEAR_INPUT_LENGTHS:
        name = (
            f"LocalDLinear_L{int(input_length)}"
            f"_K{int(config.DLINEAR_MOVING_AVG_KERNEL)}"
            f"_ep{int(config.DLINEAR_EPOCHS)}"
        )
        specs.append(
            ModelSpec(
                name=name,
                factory=lambda L=int(input_length): LocalDLinearForecaster(
                    input_length=L,
                    moving_avg_kernel=config.DLINEAR_MOVING_AVG_KERNEL,
                    epochs=config.DLINEAR_EPOCHS,
                    lr=config.DLINEAR_LR,
                    weight_decay=config.DLINEAR_WEIGHT_DECAY,
                    patience=config.DLINEAR_PATIENCE,
                    min_train_windows=config.DLINEAR_MIN_TRAIN_WINDOWS,
                    refit_every_new_points=config.DLINEAR_REFIT_EVERY_NEW_POINTS,
                    device=config.DLINEAR_DEVICE,
                    seed=config.DLINEAR_SEED,
                    debug=config.DLINEAR_DEBUG,
                ),
            )
        )

    return specs
