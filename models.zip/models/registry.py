"""Central model registry.

To add a new competitor:
1. Create models/my_model/config.py and models/my_model/my_model.py.
2. In my_model.py, expose get_model_specs() -> list[ModelSpec].
3. Import that provider below and add it to MODEL_PROVIDER_FUNCTIONS.

The evaluator never clones model instances. Each ModelSpec contains a factory
that returns a fresh model for each task.
"""

from __future__ import annotations

from typing import Callable, List

from models.registry_types import ModelSpec

# Classical group.
from models.classical import config as classical_config
from models.classical.ses import SimpleExpSmoothingForecaster
from models.classical.naive import NaiveLastValue, DriftForecaster, SeasonalNaiveForecaster
from models.classical.theta import ThetaForecaster
from models.classical.ets import ETSForecaster
from models.classical.autoarima import AutoARIMAForecaster
from models.classical.ridge import DirectRidgeForecaster

# Independent model folders.
from models.dlinear.dlinear import get_model_specs as dlinear_specs
from models.fits.fits import get_model_specs as fits_specs
from models.adaptsmooth_theta.adaptsmooth_theta import get_model_specs as adaptsmooth_theta_specs
from models.adaptsmooth_ses.adaptsmooth_ses import get_model_specs as adaptsmooth_ses
from models.adaptsmooth_chronos2.adaptsmooth_chronos2 import get_model_specs as adaptsmooth_chronos2_specs

# Foundation model folders.
from models.foundation.chronos2 import get_model_specs as chronos_specs

# Template provider, disabled by default.
from models.template_model.template_model import get_model_specs as template_model_specs


def _classical_model_specs() -> List[ModelSpec]:
    specs: List[ModelSpec] = []

    if classical_config.ENABLE_NAIVE:
        specs.append(ModelSpec(name="Naive", factory=lambda: NaiveLastValue()))

    if classical_config.ENABLE_DRIFT:
        specs.append(ModelSpec(name="Drift", factory=lambda: DriftForecaster()))

    if classical_config.ENABLE_SEASONAL_NAIVE:
        specs.append(ModelSpec(name="SeasonalNaive", factory=lambda: SeasonalNaiveForecaster()))

    if classical_config.ENABLE_AUTOARIMA:
        specs.append(ModelSpec(name="AutoARIMA", factory=lambda: AutoARIMAForecaster()))

    if classical_config.ENABLE_ETS:
        specs.append(ModelSpec(name="ETS", factory=lambda: ETSForecaster()))

    if classical_config.ENABLE_SES:
        specs.append(
            ModelSpec(
                name=classical_config.SES_MODEL_NAME,
                factory=lambda: SimpleExpSmoothingForecaster(
                    alpha=classical_config.SES_ALPHA,
                    grid_size=classical_config.SES_GRID_SIZE,
                    initial_level=classical_config.SES_INITIAL_LEVEL,
                ),
            )
        )

    if classical_config.ENABLE_THETA:
        specs.append(
            ModelSpec(
                name="Theta",
                factory=lambda: ThetaForecaster(
                    allow_seasonal=False,
                    min_seasonal_cycles=classical_config.THETA_SEASONAL_MIN_CYCLES,
                ),
            )
        )

    if classical_config.ENABLE_THETA_SEASONAL:
        specs.append(
            ModelSpec(
                name="ThetaSeasonal",
                factory=lambda: ThetaForecaster(
                    allow_seasonal=True,
                    min_seasonal_cycles=classical_config.THETA_SEASONAL_MIN_CYCLES,
                ),
            )
        )

    if classical_config.ENABLE_DIRECT_RIDGE:
        name = f"DirectRidge_lags_{classical_config.DIRECT_RIDGE_LAGS}_alpha_{classical_config.DIRECT_RIDGE_ALPHA:g}"
        specs.append(
            ModelSpec(
                name=name,
                factory=lambda: DirectRidgeForecaster(
                    lags=classical_config.DIRECT_RIDGE_LAGS,
                    alpha=classical_config.DIRECT_RIDGE_ALPHA,
                ),
            )
        )

    return specs


MODEL_PROVIDER_FUNCTIONS: List[Callable[[], List[ModelSpec]]] = [
    #_classical_model_specs,
    #dlinear_specs,
    #fits_specs,
    #adaptsmooth_theta_specs,
    #adaptsmooth_ses,
    adaptsmooth_chronos2_specs,
    #### Foundation models.
    #chronos_specs,
    # Disabled template model.
    template_model_specs,
]


def get_model_specs() -> List[ModelSpec]:
    specs: List[ModelSpec] = []

    for provider in MODEL_PROVIDER_FUNCTIONS:
        specs.extend(provider())

    names = [spec.name for spec in specs]
    if len(names) != len(set(names)):
        duplicates = sorted({name for name in names if names.count(name) > 1})
        raise ValueError(f"Duplicate model names in registry: {duplicates}")

    return specs
