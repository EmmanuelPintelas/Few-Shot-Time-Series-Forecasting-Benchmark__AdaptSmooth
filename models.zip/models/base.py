"""Common base interface for all benchmark competitors."""

from __future__ import annotations

from typing import Dict, Optional
import numpy as np


class BaseForecaster:
    """Minimal forecasting interface used by LOADER_EVALUATOR.py."""

    name = "base"

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        raise NotImplementedError

    def predict(self, n_steps: int) -> np.ndarray:
        raise NotImplementedError
