"""Shared registry datatypes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from models.base import BaseForecaster


@dataclass(frozen=True)
class ModelSpec:
    """Factory-backed model definition.

    The evaluator calls spec.factory() for every task, ensuring every run uses
    a fresh model instance without a fragile clone_model() function.
    """

    name: str
    factory: Callable[[], BaseForecaster]
