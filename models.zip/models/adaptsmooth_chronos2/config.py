"""Configuration for AdaptSmooth coupled with a Chronos-2 base forecaster.

AdaptSmooth-Chronos2 uses Chronos-2 as the base forecaster and augments its
prediction with an online-selected smoothing signal.  The smoother is selected
causally from the currently observed prefix by testing which smoother endpoint
has recently provided the best rolling short-horizon predictability.
"""

# Whether to expose this competitor through models/registry.py.
ENABLED = True
MODEL_NAME = "AdaptSmooth-Chronos2"

# Chronos-2 backbone settings.  These mirror models/foundation/config.py but are
# kept local so the AdaptSmooth variant is self-contained.
BASE_MODEL_ID = "amazon/chronos-2"
BASE_MODEL_NAME = "Chronos2"
BASE_DEVICE_MAP = "auto"        # recommended: "auto" for CPU/GPU portability
BASE_TORCH_DTYPE = "auto"       # "auto", "float32", "float16", "bfloat16"
BASE_QUANTILE = 0.5
BASE_FREQ = "D"
BASE_CONTEXT_LENGTH = None

# AdaptSmooth signal selection.
CANDIDATE_SMOOTHER_NAMES = None  # None => use active smoother_config.SMOOTHER_CANDIDATES
USE_FAST_POOL = True            # True => use smoother_config.SMOOTHER_CANDIDATES_FAST
MAX_INTERNAL_ORIGINS = 2
MIN_INTERNAL_ORIGIN = 6
RESCORE_EVERY_NEW_POINTS = 1
FALLBACK_SMOOTHER_NAME = "identity"

# Forecast stabilization coefficients.
SIGNAL_ALPHA = 0.90
BASE_FORECASTER_WEIGHT = 0.50

DEBUG = False
