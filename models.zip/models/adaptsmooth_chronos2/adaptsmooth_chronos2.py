from __future__ import annotations

from typing import Dict, List, Optional, Tuple
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, sanitize_predictions
from models.registry_types import ModelSpec
from models.foundation.chronos2 import Chronos2Forecaster
from models.smoothers import config as smoother_config
from models.smoothers.smoothers import (
    Smoother,
    make_smoother,
    get_smoother_candidates,
)
from models.adaptsmooth_chronos2 import config


def _resolve_candidate_smoothers() -> List[Smoother]:
    """Resolve the candidate smoother pool from this model's config."""
    if config.CANDIDATE_SMOOTHER_NAMES is not None:
        return get_smoother_candidates(config.CANDIDATE_SMOOTHER_NAMES)

    if bool(getattr(config, "USE_FAST_POOL", False)):
        return get_smoother_candidates(smoother_config.SMOOTHER_CANDIDATES_FAST)

    return get_smoother_candidates(smoother_config.SMOOTHER_CANDIDATES)


class AdaptSmoothChronos2Forecaster(BaseForecaster):
    """Chronos-2 augmented by an online-adapted smoothing signal.

    At each online origin, candidate smoothers are scored only on the available
    prefix.  The selected smoother endpoint is converted to a local stabilizing
    signal and coupled with the Chronos-2 forecast.  This class also exposes the
    last selected smoother, signal, and base prediction so visualization scripts
    can show the operator switching behavior.
    """

    def __init__(
        self,
        candidates: Optional[List[Smoother]] = None,
        max_internal_origins: int = 2,
        min_internal_origin: int = 6,
        rescore_every_new_points: int = 1,
        fallback_smoother_name: str = "identity",
        signal_alpha: float = 0.90,
        base_forecaster_weight: float = 0.50,
        model_name: str = "AdaptSmooth-Chronos2",
        base_model_id: str = "amazon/chronos-2",
        base_model_name: str = "Chronos2",
        base_device_map: str = "auto",
        base_torch_dtype: str = "auto",
        base_quantile: float = 0.5,
        base_freq: str = "D",
        base_context_length: Optional[int] = None,
        debug: bool = False,
    ):
        self.candidates = candidates or _resolve_candidate_smoothers()
        self.max_internal_origins = int(max_internal_origins)
        self.min_internal_origin = int(min_internal_origin)
        self.rescore_every_new_points = int(rescore_every_new_points)
        self.fallback_smoother_name = str(fallback_smoother_name)
        self.signal_alpha = float(np.clip(signal_alpha, 0.0, 1.0))
        self.base_forecaster_weight = float(np.clip(base_forecaster_weight, 0.0, 1.0))
        self.debug = bool(debug)
        self.name = str(model_name)

        self.base_ = Chronos2Forecaster(
            model_id=base_model_id,
            model_name=base_model_name,
            device_map=base_device_map,
            torch_dtype=base_torch_dtype,
            quantile=base_quantile,
            freq=base_freq,
            context_length=base_context_length,
            debug=debug,
        )

        self.raw_y_ = np.asarray([], dtype=float)
        self.selected_smoother_: Optional[Smoother] = None
        self.selection_scores_: Dict[str, float] = {}
        self.selection_history_: List[Dict[str, object]] = []
        self.last_selection_n_ = 0
        self.n_selections_ = 0
        self.n_reuses_ = 0
        self.error_: Optional[str] = None

        # Visualization/diagnostic state populated at fit()/predict().
        self.last_selected_smoother_name_: Optional[str] = None
        self.last_selected_score_: float = np.nan
        self.last_smoother_output_: Optional[np.ndarray] = None
        self.last_smooth_signal_: float = np.nan
        self.last_base_pred_: Optional[np.ndarray] = None
        self.last_final_pred_: Optional[np.ndarray] = None


    def rolling_predictability_score(
        self,
        y: np.ndarray,
        horizon: int,
        smoother: Smoother,
        max_origins: int = 4,
        min_internal_origin: int = 6,
        context: Optional[Dict] = None,
    ) -> float:
        """Causal rolling-origin score for one smoother endpoint signal.

        The smoother is applied only to each internal prefix y[:t].  Its endpoint
        signal is used as a constant local forecast for the next horizon block.
        Lower RMSE is better.
        """
        y = as_1d_float(y)
        n = len(y)
        h = int(horizon)

        if h <= 0:
            return np.inf
        if n < max(8, 2 * h + 3):
            return np.inf

        first_origin = max(int(min_internal_origin), 2 * h)
        origins = list(range(first_origin, n - h + 1, h))
        if max_origins is not None and int(max_origins) > 0 and len(origins) > int(max_origins):
            origins = origins[-int(max_origins):]
        if not origins:
            return np.inf

        sqerr: List[float] = []
        for t in origins:
            y_hist = y[:t]
            z_hist = smoother.transform(y_hist)
            target = y[t:t + h]
            if len(target) == 0:
                continue
            pred = (1-self.signal_alpha)*z_hist[-1] + self.signal_alpha*y_hist[-1]
            pred = np.repeat(pred, horizon)
            pred = sanitize_predictions(
                    pred,
                    fallback_value=float(y[-1]),
                    n_steps=len(target),
                )
            sqerr.extend(((target - pred) ** 2).astype(float).tolist())

        if not sqerr:
            return np.inf
        return float(np.sqrt(np.mean(sqerr)))

    def _should_rescore(self, n_obs: int) -> bool:
        if self.selected_smoother_ is None:
            return True
        if self.rescore_every_new_points <= 1:
            return True
        return (n_obs - self.last_selection_n_) >= self.rescore_every_new_points

    def _select_smoother(self, y: np.ndarray, horizon: int, context: Optional[Dict]) -> Tuple[Smoother, Dict[str, float]]:
        scores: Dict[str, float] = {}
        for smoother in self.candidates:
            score = self.rolling_predictability_score(
                y=y,
                horizon=horizon,
                smoother=smoother,
                max_origins=self.max_internal_origins,
                min_internal_origin=self.min_internal_origin,
                context=context,
            )
            scores[smoother.name] = score

        finite_scores = {name: score for name, score in scores.items() if np.isfinite(score)}
        if finite_scores:
            best_name = min(finite_scores, key=finite_scores.get)
            return make_smoother(best_name), scores

        try:
            return make_smoother(self.fallback_smoother_name), scores
        except Exception:
            return make_smoother("identity"), scores

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.raw_y_ = as_1d_float(y)
        self.error_ = None

        if len(self.raw_y_) == 0:
            return self

        if self._should_rescore(len(self.raw_y_)):
            self.selected_smoother_, self.selection_scores_ = self._select_smoother(
                y=self.raw_y_,
                horizon=horizon,
                context=context,
            )
            self.last_selection_n_ = len(self.raw_y_)
            self.n_selections_ += 1
        else:
            self.n_reuses_ += 1

        self.base_.fit(self.raw_y_, horizon=horizon, context=context)
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        self.last_base_pred_ = None
        self.last_final_pred_ = None
        n_steps = int(n_steps)
        fallback = float(self.raw_y_[-1]) if len(self.raw_y_) else 0.0
        if n_steps <= 0:
            return np.asarray([], dtype=float)

        try:
            base_pred = self.base_.predict(n_steps)
            base_pred = sanitize_predictions(base_pred, fallback_value=fallback, n_steps=n_steps)


            self.last_selected_smoother_name_ = self.selected_smoother_.name
            self.last_selected_score_ = float(self.selection_scores_.get(self.selected_smoother_.name, np.nan))

            z_ = self.selected_smoother_.transform(self.raw_y_)
            self.last_smoother_output_ = z_
            signal = (1-self.signal_alpha)*z_[-1] + self.signal_alpha*self.raw_y_[-1]
            self.last_smooth_signal_ = signal

            self.selection_history_.append(
                {
                    "n_obs": int(len(self.raw_y_)),
                    "horizon": int(n_steps),
                    "selected_smoother": self.last_selected_smoother_name_,
                    "selected_score": self.last_selected_score_ if np.isfinite(self.last_selected_score_) else None,
                    "smooth_signal": float(self.last_smooth_signal_),
                }
            )

            signal_pred = np.repeat(float(signal), n_steps)
            pred = (1.0 - self.base_forecaster_weight) * signal_pred + self.base_forecaster_weight * base_pred # stabilizing forecaster via online-adapted signal s

        except Exception as exc:
            self.error_ = str(exc)
            base_pred = np.repeat(fallback, n_steps)
            pred = np.repeat(fallback, n_steps)

        self.last_base_pred_ = np.asarray(base_pred, dtype=float)
        self.last_final_pred_ = np.asarray(pred, dtype=float)

        return sanitize_predictions(pred, fallback_value=fallback, n_steps=n_steps)


    def get_last_prediction_components(self) -> Dict[str, object]:
        """Return diagnostics for the most recent fit/predict origin."""
        return {
            "selected_smoother": self.last_selected_smoother_name_,
            "selected_score": self.last_selected_score_,
            "smooth_signal": self.last_smooth_signal_,
            "smoother_output": self.last_smoother_output_,
            "base_pred": self.last_base_pred_,
            "final_pred": self.last_final_pred_,
            "signal_alpha": self.signal_alpha,
            "base_forecaster_weight": self.base_forecaster_weight,
        }


def get_model_specs() -> List[ModelSpec]:
    if not bool(getattr(config, "ENABLED", False)):
        return []

    def factory() -> BaseForecaster:
        return AdaptSmoothChronos2Forecaster(
            candidates=_resolve_candidate_smoothers(),
            max_internal_origins=config.MAX_INTERNAL_ORIGINS,
            min_internal_origin=config.MIN_INTERNAL_ORIGIN,
            rescore_every_new_points=config.RESCORE_EVERY_NEW_POINTS,
            fallback_smoother_name=config.FALLBACK_SMOOTHER_NAME,
            signal_alpha=config.SIGNAL_ALPHA,
            base_forecaster_weight=config.BASE_FORECASTER_WEIGHT,
            model_name=config.MODEL_NAME,
            base_model_id=config.BASE_MODEL_ID,
            base_model_name=config.BASE_MODEL_NAME,
            base_device_map=config.BASE_DEVICE_MAP,
            base_torch_dtype=config.BASE_TORCH_DTYPE,
            base_quantile=config.BASE_QUANTILE,
            base_freq=config.BASE_FREQ,
            base_context_length=config.BASE_CONTEXT_LENGTH,
            debug=config.DEBUG,
        )

    return [ModelSpec(name=config.MODEL_NAME, factory=factory)]
