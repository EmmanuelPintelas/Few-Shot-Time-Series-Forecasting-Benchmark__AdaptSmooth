"""Configuration for the local FITS competitor.

FITS (Frequency Interpolation Time Series Forecasting) is a lightweight
frequency-domain model. In this benchmark it is trained from scratch on the
currently available few-shot prefix at each online origin, with no external
pretraining.
"""

# Enable/disable all FITS variants exposed by models/fits/fits.py.
ENABLE_FITS = True

# One model is created for each input length in this list.
# Short lengths are safer for supports as small as 10 timestamps.
FITS_INPUT_LENGTHS = [5]

# Number of low-frequency rFFT coefficients retained before interpolation.
# Use "auto" to keep all frequencies available from each input window.
# For L=5, rfft has 3 coefficients, so 3 is equivalent to all frequencies.
FITS_CUT_FREQ = "auto"

# Training settings.
FITS_EPOCHS = 20
FITS_LR = 0.01
FITS_WEIGHT_DECAY = 1e-4
FITS_PATIENCE = 10
FITS_MIN_TRAIN_WINDOWS = 3

# Refit policy. If 0 or 1, retrain at every online origin. If 50, retrain only
# after 50 newly revealed observations since the last successful refit.
FITS_REFIT_EVERY_NEW_POINTS = 10

# Device. Use "auto" to select CUDA when available, otherwise CPU.
FITS_DEVICE = "auto"

# Reproducibility.
FITS_SEED = 42

# Print per-fit diagnostics. Useful for debugging; disable for final runs.
FITS_DEBUG = False
