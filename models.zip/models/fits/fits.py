from __future__ import annotations

from typing import Dict, List, Optional, Union
import math
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, is_constant, fallback_last, sanitize_predictions
from models.registry_types import ModelSpec
from models.fits import config

try:
    import torch
    import torch.nn as nn
except Exception:  # pragma: no cover
    torch = None
    nn = None


class LocalFITSForecaster(BaseForecaster):
    """Local-from-scratch FITS baseline.

    FITS is a lightweight frequency-domain forecaster. It normalizes the input
    window, keeps low-frequency rFFT coefficients, learns a complex-valued
    interpolation from the input spectrum to the longer input+forecast spectrum,
    and reconstructs the future values by inverse rFFT.

    This wrapper is intentionally local: it trains only on the currently
    observed prefix supplied by the evaluator. It is therefore a strict
    few-shot, no-pretraining competitor.
    """

    def __init__(
        self,
        input_length: int = 5,
        cut_freq: Union[int, str] = "auto",
        epochs: int = 80,
        lr: float = 0.01,
        weight_decay: float = 1e-4,
        patience: int = 10,
        min_train_windows: int = 3,
        refit_every_new_points: int = 1,
        device: str = "auto",
        seed: int = 42,
        debug: bool = False,
    ):
        self.input_length = int(input_length)
        self.cut_freq = cut_freq
        self.epochs = int(epochs)
        self.lr = float(lr)
        self.weight_decay = float(weight_decay)
        self.patience = int(patience)
        self.min_train_windows = int(min_train_windows)
        self.refit_every_new_points = int(refit_every_new_points)
        self.device_setting = str(device)
        self.seed = int(seed)
        self.debug = bool(debug)

        cut_label = "auto" if str(cut_freq).lower() == "auto" else str(int(cut_freq))
        self.name = f"LocalFITS_L{self.input_length}_C{cut_label}_ep{self.epochs}"

        self.y_ = np.asarray([], dtype=float)
        self.model_ = None
        self.output_horizon_ = 1
        self.last_refit_n_ = 0
        self.n_refits_ = 0
        self.n_skips_ = 0
        self.n_failures_ = 0
        self.error_ = None

    class _ComplexLinear(nn.Module):
        """Small complex linear map implemented with real parameters.

        Given z = x_r + i x_i, W = W_r + i W_i,
        Wz = (W_r x_r - W_i x_i) + i(W_r x_i + W_i x_r).
        """

        def __init__(self, in_features: int, out_features: int):
            super().__init__()
            self.in_features = int(in_features)
            self.out_features = int(out_features)

            scale = 1.0 / math.sqrt(max(1, self.in_features))
            self.weight_real = nn.Parameter(torch.empty(out_features, in_features))
            self.weight_imag = nn.Parameter(torch.empty(out_features, in_features))
            self.bias_real = nn.Parameter(torch.zeros(out_features))
            self.bias_imag = nn.Parameter(torch.zeros(out_features))

            nn.init.uniform_(self.weight_real, -scale, scale)
            nn.init.uniform_(self.weight_imag, -scale, scale)

            # Start near identity/copy for the overlapping low-frequency bins.
            with torch.no_grad():
                self.weight_real.zero_()
                self.weight_imag.zero_()
                n_copy = min(self.in_features, self.out_features)
                for i in range(n_copy):
                    self.weight_real[i, i] = 1.0

        def forward(self, z: torch.Tensor) -> torch.Tensor:
            xr = z.real
            xi = z.imag
            yr = torch.nn.functional.linear(xr, self.weight_real, self.bias_real) - torch.nn.functional.linear(xi, self.weight_imag, None)
            yi = torch.nn.functional.linear(xr, self.weight_imag, self.bias_imag) + torch.nn.functional.linear(xi, self.weight_real, None)
            return torch.complex(yr, yi)

    class _FITSTorchModel(nn.Module):
        def __init__(self, input_length: int, output_horizon: int, cut_freq: Union[int, str]):
            super().__init__()
            self.input_length = int(input_length)
            self.output_horizon = int(output_horizon)
            self.total_length = self.input_length + self.output_horizon
            self.length_ratio = float(self.total_length) / float(self.input_length)

            input_freq_len = self.input_length // 2 + 1
            output_freq_len = self.total_length // 2 + 1

            if str(cut_freq).lower() == "auto":
                self.cut_freq = input_freq_len
            else:
                self.cut_freq = int(cut_freq)

            self.cut_freq = max(1, min(self.cut_freq, input_freq_len))
            self.output_cut_freq = max(1, min(int(math.ceil(self.cut_freq * self.length_ratio)), output_freq_len))
            self.output_freq_len = output_freq_len

            self.freq_interpolator = LocalFITSForecaster._ComplexLinear(
                in_features=self.cut_freq,
                out_features=self.output_cut_freq,
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            """Forecast from an input window.

            x shape: [batch, input_length]
            output shape: [batch, output_horizon]
            """
            mean = x.mean(dim=1, keepdim=True)
            centered = x - mean
            std = torch.sqrt(torch.var(centered, dim=1, keepdim=True, unbiased=False) + 1e-5)
            x_norm = centered / std

            spec = torch.fft.rfft(x_norm, dim=1)
            low_spec = spec[:, :self.cut_freq]

            interp_low = self.freq_interpolator(low_spec)

            full_spec = torch.zeros(
                x.shape[0],
                self.output_freq_len,
                dtype=torch.complex64,
                device=x.device,
            )
            full_spec[:, :self.output_cut_freq] = interp_low

            reconstructed = torch.fft.irfft(full_spec, n=self.total_length, dim=1)
            reconstructed = reconstructed * self.length_ratio
            reconstructed = reconstructed * std + mean

            return reconstructed[:, -self.output_horizon:]

    def _resolve_device(self) -> str:
        if torch is None:
            return "cpu"
        if self.device_setting == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        if self.device_setting == "cuda" and not torch.cuda.is_available():
            return "cpu"
        return self.device_setting

    def _make_xy(self, y: np.ndarray, horizon: int):
        X, target = [], []
        L = self.input_length
        H = int(horizon)

        max_start = len(y) - L - H + 1
        if max_start <= 0:
            return None, None

        for start in range(max_start):
            X.append(y[start:start + L])
            target.append(y[start + L:start + L + H])

        if not X:
            return None, None

        return np.asarray(X, dtype=float), np.asarray(target, dtype=float)

    def _should_refit(self, n_obs: int) -> bool:
        if self.model_ is None:
            return True
        if self.refit_every_new_points <= 1:
            return True
        return (n_obs - self.last_refit_n_) >= self.refit_every_new_points

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        self.error_ = None
        self.output_horizon_ = max(1, int(horizon))

        if torch is None or nn is None:
            self.model_ = None
            self.error_ = "PyTorch is not installed"
            return self

        if len(self.y_) < self.input_length + self.output_horizon_ or is_constant(self.y_):
            self.error_ = "too short or constant"
            return self

        if not self._should_refit(len(self.y_)):
            self.n_skips_ += 1
            return self

        X, target = self._make_xy(self.y_, self.output_horizon_)
        if X is None or len(X) < self.min_train_windows:
            self.model_ = None
            self.error_ = "not enough training windows"
            return self

        try:
            torch.manual_seed(self.seed)
            np.random.seed(self.seed)

            device = self._resolve_device()
            X_tensor = torch.tensor(X, dtype=torch.float32, device=device)
            y_tensor = torch.tensor(target, dtype=torch.float32, device=device)

            model = self._FITSTorchModel(
                input_length=self.input_length,
                output_horizon=self.output_horizon_,
                cut_freq=self.cut_freq,
            ).to(device)

            optimizer = torch.optim.Adam(
                model.parameters(),
                lr=self.lr,
                weight_decay=self.weight_decay,
            )
            loss_fn = nn.MSELoss()

            best_loss = float("inf")
            best_state = None
            bad_epochs = 0

            model.train()
            for _ in range(self.epochs):
                optimizer.zero_grad(set_to_none=True)
                pred = model(X_tensor)
                loss = loss_fn(pred, y_tensor)

                if not torch.isfinite(loss):
                    self.model_ = None
                    self.error_ = "non-finite loss"
                    return self

                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()

                loss_value = float(loss.detach().cpu())
                if loss_value + 1e-8 < best_loss:
                    best_loss = loss_value
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                    bad_epochs = 0
                else:
                    bad_epochs += 1

                if bad_epochs >= self.patience:
                    break

            if best_state is not None:
                model.load_state_dict(best_state)

            model.eval()
            self.model_ = model
            self.device_ = device
            self.last_refit_n_ = len(self.y_)
            self.n_refits_ += 1

            if self.debug:
                print(
                    f"[FITS FIT] n={len(self.y_)}, L={self.input_length}, "
                    f"H={self.output_horizon_}, windows={len(X)}, "
                    f"cut={model.cut_freq}, out_cut={model.output_cut_freq}, "
                    f"device={device}, loss={best_loss:.6f}"
                )

        except Exception as exc:
            self.model_ = None
            self.error_ = repr(exc)
            self.n_failures_ += 1
            if self.debug:
                print(f"[FITS ERROR] {self.error_}")

        return self

    def _predict_direct(self, n_steps: int) -> Optional[np.ndarray]:
        if self.model_ is None or torch is None:
            return None
        if len(self.y_) < self.input_length:
            return None

        device = getattr(self, "device_", self._resolve_device())
        x = self.y_[-self.input_length:]

        with torch.no_grad():
            x_tensor = torch.tensor(x.reshape(1, -1), dtype=torch.float32, device=device)
            pred = self.model_(x_tensor).detach().cpu().numpy().reshape(-1)

        return pred[:n_steps]

    def predict(self, n_steps: int) -> np.ndarray:
        if len(self.y_) == 0:
            return np.zeros(n_steps, dtype=float)
        if self.model_ is None:
            return fallback_last(self.y_, n_steps)

        try:
            # Direct case, which is the usual evaluator call when n_steps == horizon.
            if n_steps <= self.output_horizon_:
                pred = self._predict_direct(n_steps)
                if pred is None or len(pred) != n_steps:
                    return fallback_last(self.y_, n_steps)
                return sanitize_predictions(pred, fallback_value=float(self.y_[-1]), n_steps=n_steps)

            # Rare case: requested n_steps is longer than trained horizon. Roll forward.
            hist = self.y_.copy()
            preds = []
            while len(preds) < n_steps:
                old_y = self.y_
                self.y_ = hist
                block = self._predict_direct(min(self.output_horizon_, n_steps - len(preds)))
                self.y_ = old_y
                if block is None or len(block) == 0:
                    break
                preds.extend(block.tolist())
                hist = np.concatenate([hist, np.asarray(block, dtype=float)])

            if len(preds) != n_steps:
                return fallback_last(self.y_, n_steps)

            return sanitize_predictions(
                np.asarray(preds, dtype=float),
                fallback_value=float(self.y_[-1]),
                n_steps=n_steps,
            )

        except Exception:
            return fallback_last(self.y_, n_steps)


def get_model_specs() -> List[ModelSpec]:
    if not config.ENABLE_FITS:
        return []

    specs: List[ModelSpec] = []
    for input_length in config.FITS_INPUT_LENGTHS:
        cut_label = "auto" if str(config.FITS_CUT_FREQ).lower() == "auto" else str(int(config.FITS_CUT_FREQ))
        name = (
            f"LocalFITS_L{int(input_length)}"
            f"_C{cut_label}"
            f"_ep{int(config.FITS_EPOCHS)}"
        )
        specs.append(
            ModelSpec(
                name=name,
                factory=lambda L=int(input_length): LocalFITSForecaster(
                    input_length=L,
                    cut_freq=config.FITS_CUT_FREQ,
                    epochs=config.FITS_EPOCHS,
                    lr=config.FITS_LR,
                    weight_decay=config.FITS_WEIGHT_DECAY,
                    patience=config.FITS_PATIENCE,
                    min_train_windows=config.FITS_MIN_TRAIN_WINDOWS,
                    refit_every_new_points=config.FITS_REFIT_EVERY_NEW_POINTS,
                    device=config.FITS_DEVICE,
                    seed=config.FITS_SEED,
                    debug=config.FITS_DEBUG,
                ),
            )
        )

    return specs
