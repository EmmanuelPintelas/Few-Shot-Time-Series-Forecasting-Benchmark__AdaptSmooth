from __future__ import annotations

from typing import Dict, List, Optional, Tuple
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, sanitize_predictions
from models.classical.theta import ThetaForecaster
from models.registry_types import ModelSpec
from models.smoothers import config as smoother_config
from models.smoothers.smoothers import (
    Smoother,
    make_smoother,
    get_smoother_candidates,
)
from models.adaptsmooth_theta import config


def _resolve_candidate_smoothers() -> List[Smoother]:
    """Resolve the candidate pool from this model's config."""
    if config.CANDIDATE_SMOOTHER_NAMES is not None:
        return get_smoother_candidates(config.CANDIDATE_SMOOTHER_NAMES)

    if bool(getattr(config, "USE_FAST_POOL", False)):
        return get_smoother_candidates(smoother_config.SMOOTHER_CANDIDATES_FAST)

    return get_smoother_candidates(smoother_config.SMOOTHER_CANDIDATES)





class AdaptSmoothThetaForecaster(BaseForecaster):
    """AdaptSmooth with a Theta backbone.

    Difference from ``SupportSelectedStaticSmoother_Theta``:
        * Support-selected static smoother chooses a smoother once and keeps it
          fixed for the whole task.
        * AdaptSmoothTheta re-scores the candidate pool at each online origin
          by default, so the selected representation can evolve as query values
          are revealed.

    The evaluator supplies already-transformed data, e.g. signed-log1p if that
    global option is enabled.  Therefore this model operates fully on the
    evaluator's working scale and returns forecasts on that same scale.
    """

    def __init__(
        self,
        candidates: Optional[List[Smoother]] = None,
        allow_seasonal: bool = False,
        min_seasonal_cycles: int = 3,
        max_internal_origins: int = 4,
        min_internal_origin: int = 6,
        rescore_every_new_points: int = 1,
        fallback_smoother_name: str = "identity",
        model_name: str = "AdaptSmooth_Theta",
        debug: bool = False,
    ):
        self.candidates = candidates or _resolve_candidate_smoothers()
        self.a = 0.9
        self.b = 0.5
        self.allow_seasonal = bool(allow_seasonal)
        self.min_seasonal_cycles = int(min_seasonal_cycles)
        self.max_internal_origins = int(max_internal_origins)
        self.min_internal_origin = int(min_internal_origin)
        self.rescore_every_new_points = int(rescore_every_new_points)
        self.fallback_smoother_name = str(fallback_smoother_name)
        self.debug = bool(debug)

        self.name = str(model_name)

        self.raw_y_ = np.asarray([], dtype=float)
        self.theta_ = ThetaForecaster(
            allow_seasonal=self.allow_seasonal,
            min_seasonal_cycles=self.min_seasonal_cycles,
        )

        self.selected_smoother_: Optional[Smoother] = None
        self.selection_scores_: Dict[str, float] = {}
        self.selection_history_: List[Dict[str, object]] = []
        self.last_selection_n_ = 0
        self.n_selections_ = 0
        self.n_reuses_ = 0
        self.error_: Optional[str] = None

    def rolling_predictability_score_theta(self,
        y: np.ndarray,
        horizon: int,
        smoother: Smoother,
        max_origins: int = 4,
        min_internal_origin: int = 6,
        allow_seasonal: bool = False,
        min_seasonal_cycles: int = 3,
        context: Optional[Dict] = None,
    ) -> float:
        """Causal rolling-origin score for one smoother using a Theta backbone.

        The score uses only prefixes of the currently observed history ``y``.  For
        each internal origin t, the smoother is applied only to y[:t], Theta is fit
        on that transformed prefix, and the next ``horizon`` observed values are
        used as the validation target.  Lower RMSE is better.
        """
        y = as_1d_float(y)
        n = len(y)
        h = int(horizon)

        if h <= 0:
            return np.inf

        if n < max(8, 2 * h + 3):
            return np.inf

        first_origin = max(int(min_internal_origin), 2 * h)
        origins = list(range(first_origin, n - h + 1, h))

        if max_origins is not None and int(max_origins) > 0 and len(origins) > int(max_origins):
            origins = origins[-int(max_origins):]

        if not origins:
            return np.inf

        sqerr: List[float] = []



        for t in origins:
            y_hist = y[:t]
            z_hist = smoother.transform(y_hist)
            target = y[t:t + h]
            if len(target) == 0:
                continue
            pred = (1-self.a)*z_hist[-1] + self.a*y_hist[-1]
            pred = np.repeat(pred, horizon)
            pred = sanitize_predictions(
                    pred,
                    fallback_value=float(y[-1]),
                    n_steps=len(target),
                )

            sqerr.extend(((target - pred) ** 2).astype(float).tolist())


        if not sqerr:
            return np.inf

        return float(np.sqrt(np.mean(sqerr)))


    def _should_rescore(self, n_obs: int) -> bool:
        if self.selected_smoother_ is None:
            return True

        if self.rescore_every_new_points <= 1:
            return True

        return (n_obs - self.last_selection_n_) >= self.rescore_every_new_points

    def _select_smoother(
        self,
        y: np.ndarray,
        horizon: int,
        context: Optional[Dict],
    ) -> Tuple[Smoother, Dict[str, float]]:
        scores: Dict[str, float] = {}

        for smoother in self.candidates:
            score = self.rolling_predictability_score_theta(
                y=y,
                horizon=horizon,
                smoother=smoother,
                max_origins=self.max_internal_origins,
                min_internal_origin=self.min_internal_origin,
                allow_seasonal=self.allow_seasonal,
                min_seasonal_cycles=self.min_seasonal_cycles,
                context=context,
            )
            scores[smoother.name] = score

        finite_scores = {name: score for name, score in scores.items() if np.isfinite(score)}

        if finite_scores:
            best_name = min(finite_scores, key=finite_scores.get)
            return make_smoother(best_name), scores

        try:
            return make_smoother(self.fallback_smoother_name), scores
        except Exception:
            return make_smoother("identity"), scores

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.raw_y_ = as_1d_float(y)
        self.error_ = None

        if len(self.raw_y_) == 0:
            return self

        if self._should_rescore(len(self.raw_y_)):
                self.selected_smoother_, self.selection_scores_ = self._select_smoother(
                    y=self.raw_y_,
                    horizon=horizon,
                    context=context,
                )
                self.last_selection_n_ = len(self.raw_y_)
                self.n_selections_ += 1

                selected_score = self.selection_scores_.get(self.selected_smoother_.name, np.nan)
                self.selection_history_.append(
                    {
                        "n_obs": int(len(self.raw_y_)),
                        "horizon": int(horizon),
                        "selected_smoother": self.selected_smoother_.name,
                        "selected_score": float(selected_score) if np.isfinite(selected_score) else None,
                    }
                )

                if self.debug:
                    print(
                        f"[AdaptSmoothTheta] n={len(self.raw_y_)}, "
                        f"selected={self.selected_smoother_.name}, "
                        f"score={selected_score}"
                    )
        else:
                self.n_reuses_ += 1

        smoother = self.selected_smoother_# or make_smoother(self.fallback_smoother_name)
        z = smoother.transform(self.raw_y_)

        if len(z) != len(self.raw_y_) or not np.isfinite(z).all():
                z = self.raw_y_.copy()

        self.theta_ = ThetaForecaster(allow_seasonal=self.allow_seasonal,min_seasonal_cycles=self.min_seasonal_cycles,).fit(self.raw_y_, horizon=horizon, context=context)

        return self

    def predict(self, n_steps: int) -> np.ndarray:
        fallback = float(self.raw_y_[-1]) if len(self.raw_y_) else 0.0

        try:
            s = (1-self.a)*self.selected_smoother_.transform(self.raw_y_)[-1] + self.a*self.raw_y_[-1]
            s = np.repeat(s, n_steps) # online-adapted signal
            pred = (1-self.b)*s + self.b*self.theta_.predict(n_steps) # stabilizing forecaster via online-adapted signal s

        except Exception:
            pred = np.repeat(fallback, n_steps)

        return sanitize_predictions(
            pred,
            fallback_value=fallback,
            n_steps=n_steps,
        )



def get_model_specs() -> List[ModelSpec]:
    if not config.ENABLED:
        return []

    def factory() -> BaseForecaster:
        return AdaptSmoothThetaForecaster(
            candidates=_resolve_candidate_smoothers(),
            allow_seasonal=config.ALLOW_SEASONAL,
            min_seasonal_cycles=config.MIN_SEASONAL_CYCLES,
            max_internal_origins=config.MAX_INTERNAL_ORIGINS,
            min_internal_origin=config.MIN_INTERNAL_ORIGIN,
            rescore_every_new_points=config.RESCORE_EVERY_NEW_POINTS,
            fallback_smoother_name=config.FALLBACK_SMOOTHER_NAME,
            model_name=config.MODEL_NAME,
            debug=config.DEBUG,
        )

    return [
        ModelSpec(
            name=config.MODEL_NAME,
            factory=factory,
        )
    ]
