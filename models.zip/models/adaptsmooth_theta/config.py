"""AdaptSmooth + Theta configuration.

This competitor implements the proposed online representation-adaptation method
with a Theta forecasting backbone.  At every online origin, it re-scores a pool
of smoothing transformations using only the currently observed prefix, selects
one transformation, fits Theta on the transformed prefix, and forecasts the next
block.
"""

# Enable/disable this competitor.
ENABLED = True

# Model name written to predictions/metrics.  Rename to "AdaptAugment_Theta" if
# you decide to publish the method under that name instead of AdaptSmooth.
MODEL_NAME = "AdaptSmooth_Theta"

# Candidate smoother pool.
# None means use the active pool from models/smoothers/config.py
# (SMOOTHER_CANDIDATES).  For fast debugging, set USE_FAST_POOL=True.
CANDIDATE_SMOOTHER_NAMES = None
USE_FAST_POOL = True

# Rolling predictability scoring.
# A small number keeps the method feasible in strict online evaluation while
# still making the decision causal and task-time adaptive.
MAX_INTERNAL_ORIGINS = 2#4

# The first internal rolling origin is max(MIN_INTERNAL_ORIGIN, 2*horizon).
MIN_INTERNAL_ORIGIN = 6

# Online re-selection policy.
# 1 means re-score/select at every prediction origin, which is the canonical
# AdaptSmooth behavior. Larger values reuse the last selected transform until
# enough new observations have arrived.
RESCORE_EVERY_NEW_POINTS = 1

# Theta settings for both scoring and final forecasting.
ALLOW_SEASONAL = False
MIN_SEASONAL_CYCLES = 3

# Conservative fallback if no candidate receives a finite score.
FALLBACK_SMOOTHER_NAME = "identity"

# If True, prints selected smoother and score at every re-selection.
DEBUG = False
