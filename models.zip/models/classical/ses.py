from __future__ import annotations

from typing import Dict, Optional
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, sanitize_predictions
from models.classical import config


class SimpleExpSmoothingForecaster(BaseForecaster):
    """Simple Exponential Smoothing baseline.

    This is the local-level exponential smoothing model:

        level_t = alpha * y_t + (1 - alpha) * level_{t-1}
        forecast_{t+h} = level_t, for h >= 1

    It is intentionally trend/seasonality-free, making it a clean comparison
    point for adaptive smoother methods whose fallback signal is also a local
    level forecast.
    """

    name = "SES"

    def __init__(
        self,
        alpha: Optional[float] = None,
        grid_size: int = 99,
        initial_level: str = "first",
    ):
        self.alpha = alpha
        self.grid_size = int(grid_size)
        self.initial_level = str(initial_level)
        self.y_ = np.asarray([], dtype=float)
        self.level_ = 0.0
        self.alpha_ = np.nan
        self.sse_ = np.inf
        self.error_: Optional[str] = None

    @staticmethod
    def _validate_alpha(alpha: float) -> float:
        a = float(alpha)
        if not np.isfinite(a) or not (0.0 < a <= 1.0):
            raise ValueError("SES alpha must be finite and in the interval (0, 1].")
        return a

    def _initial_level(self, y: np.ndarray) -> float:
        if len(y) == 0:
            return 0.0
        method = self.initial_level.lower()
        if method == "mean_first_2" and len(y) >= 2:
            return float(np.mean(y[:2]))
        if method == "mean_first_3" and len(y) >= 3:
            return float(np.mean(y[:3]))
        return float(y[0])

    def _fit_with_alpha(self, y: np.ndarray, alpha: float) -> tuple[float, float]:
        """Return final level and one-step-ahead SSE for a fixed alpha."""
        if len(y) == 0:
            return 0.0, 0.0

        level = self._initial_level(y)
        sse = 0.0

        # At time t, forecast y[t] using level from t-1, then update level.
        for t in range(1, len(y)):
            err = float(y[t] - level)
            sse += err * err
            level = alpha * float(y[t]) + (1.0 - alpha) * level

        return float(level), float(sse)

    def _candidate_alphas(self) -> np.ndarray:
        if self.alpha is not None:
            return np.asarray([self._validate_alpha(self.alpha)], dtype=float)

        # Avoid alpha=0 because it never updates; include alpha=1 as naive last value.
        k = max(2, int(self.grid_size))
        return np.linspace(1.0 / k, 1.0, k, dtype=float)

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        self.error_ = None

        if len(self.y_) == 0:
            self.level_ = 0.0
            self.alpha_ = np.nan
            self.sse_ = np.inf
            return self

        if len(self.y_) == 1:
            self.level_ = float(self.y_[-1])
            self.alpha_ = self._validate_alpha(self.alpha) if self.alpha is not None else 1.0
            self.sse_ = 0.0
            return self

        best_alpha = None
        best_level = float(self.y_[-1])
        best_sse = np.inf

        try:
            for alpha in self._candidate_alphas():
                level, sse = self._fit_with_alpha(self.y_, float(alpha))
                if sse < best_sse:
                    best_alpha = float(alpha)
                    best_level = float(level)
                    best_sse = float(sse)
        except Exception as exc:
            self.error_ = str(exc)
            self.level_ = float(self.y_[-1])
            self.alpha_ = np.nan
            self.sse_ = np.inf
            return self

        self.alpha_ = float(best_alpha) if best_alpha is not None else np.nan
        if self.alpha_ != 1:
            sss = 1
        self.level_ = float(best_level)
        self.sse_ = float(best_sse)
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        fallback = float(self.y_[-1]) if len(self.y_) else 0.0
        pred = np.repeat(self.level_, int(n_steps))
        return sanitize_predictions(pred, fallback_value=fallback, n_steps=int(n_steps))


def get_model_specs():
    from typing import List
    from models.registry_types import ModelSpec

    if not config.ENABLE_SES:
        return []

    return [
        ModelSpec(
            name=config.SES_MODEL_NAME,
            factory=lambda: SimpleExpSmoothingForecaster(
                alpha=config.SES_ALPHA,
                grid_size=config.SES_GRID_SIZE,
                initial_level=config.SES_INITIAL_LEVEL,
            ),
        )
    ]
