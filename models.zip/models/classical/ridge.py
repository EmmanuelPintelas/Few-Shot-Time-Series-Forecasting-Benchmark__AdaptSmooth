from __future__ import annotations

from typing import Dict, Optional
import numpy as np

from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

from models.base import BaseForecaster
from models.model_utils import as_1d_float, is_constant, fallback_last, sanitize_predictions


class DirectRidgeForecaster(BaseForecaster):
    def __init__(self, lags: int = 5, alpha: float = 1.0):
        self.lags = int(lags)
        self.alpha = float(alpha)
        self.name = f"DirectRidge_lags_{self.lags}_alpha_{self.alpha:g}"
        self.model_ = None
        self.y_ = np.asarray([], dtype=float)

    def _make_xy(self, y: np.ndarray):
        X, target = [], []
        for t in range(self.lags, len(y)):
            X.append(y[t - self.lags:t])
            target.append(y[t])

        if not X:
            return None, None

        return np.asarray(X, dtype=float), np.asarray(target, dtype=float)

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        self.model_ = None

        if len(self.y_) < self.lags + 3 or is_constant(self.y_):
            return self

        X, target = self._make_xy(self.y_)
        if X is None or len(X) < 3:
            return self

        self.model_ = make_pipeline(StandardScaler(), Ridge(alpha=self.alpha))
        self.model_.fit(X, target)
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        if len(self.y_) == 0:
            return np.zeros(n_steps, dtype=float)

        if self.model_ is None:
            return fallback_last(self.y_, n_steps)

        hist = self.y_.copy()
        preds = []

        for _ in range(n_steps):
            if len(hist) < self.lags:
                pred = float(hist[-1])
            else:
                x = hist[-self.lags:].reshape(1, -1)
                pred = float(self.model_.predict(x)[0])

            preds.append(pred)
            hist = np.append(hist, pred)

        return sanitize_predictions(
            np.asarray(preds, dtype=float),
            fallback_value=float(self.y_[-1]),
            n_steps=n_steps,
        )
