"""Configuration for classical forecasters."""

# Enable/disable classical competitors in models/registry.py via this config.
ENABLE_SES = True
ENABLE_NAIVE = True
ENABLE_DRIFT = True
ENABLE_SEASONAL_NAIVE = True
ENABLE_AUTOARIMA = True
ENABLE_ETS = True
ENABLE_THETA = True
ENABLE_THETA_SEASONAL = False
##ENABLE_DIRECT_RIDGE = False

# Auto-ARIMA settings.
AUTO_ARIMA_MAX_P = 2
AUTO_ARIMA_MAX_Q = 2
AUTO_ARIMA_MAX_D = 1
AUTO_ARIMA_MAX_ORDER = 4
AUTO_ARIMA_RESEARCH_EVERY_NEW_POINTS = 50
AUTO_ARIMA_UPDATE_MAXITER = 5

# Theta settings.
THETA_ALLOW_SEASONAL = False
THETA_SEASONAL_MIN_CYCLES = 3

# Ridge settings.
DIRECT_RIDGE_LAGS = 5
DIRECT_RIDGE_ALPHA = 1.0

# Simple Exponential Smoothing settings.
# SES_ALPHA=None chooses alpha by minimizing in-sample one-step SSE over a grid.
# Set SES_ALPHA to a fixed value such as 0.2 to use the textbook fixed-alpha form.
SES_MODEL_NAME = "SES"
SES_ALPHA = None
SES_GRID_SIZE = 99
SES_INITIAL_LEVEL = "first"  # options: "first", "mean_first_2", "mean_first_3"
