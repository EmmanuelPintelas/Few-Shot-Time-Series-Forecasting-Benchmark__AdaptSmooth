from __future__ import annotations

from typing import Dict, Optional
import numpy as np
import pandas as pd

from statsmodels.tsa.forecasting.theta import ThetaModel

from models.base import BaseForecaster
from models.model_utils import as_1d_float, is_constant, fallback_last


class ThetaForecaster(BaseForecaster):
    def __init__(self, allow_seasonal: bool = False, min_seasonal_cycles: int = 3):
        self.allow_seasonal = allow_seasonal
        self.min_seasonal_cycles = min_seasonal_cycles
        self.name = "ThetaSeasonal" if allow_seasonal else "Theta"

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        self.model_ = None
        self.error_ = None

        if ThetaModel is None:
            self.error_ = "ThetaModel not available"
            return self

        if len(self.y_) < 4 or is_constant(self.y_):
            self.error_ = "too short or constant"
            return self

        context = context or {}
        seasonal_period = context.get("seasonal_period", None)
        endog = pd.Series(self.y_)

        try_configs = []
        if (
            self.allow_seasonal
            and seasonal_period is not None
            and len(self.y_) >= self.min_seasonal_cycles * int(seasonal_period)
        ):
            try_configs.append({"period": int(seasonal_period), "deseasonalize": True})

        try_configs.append({"deseasonalize": False})

        for kwargs in try_configs:
            try:
                self.model_ = ThetaModel(endog, **kwargs).fit()
                self.error_ = None
                return self
            except Exception as exc:
                self.error_ = repr(exc)

        return self

    def predict(self, n_steps: int) -> np.ndarray:
        if self.model_ is None:
            return fallback_last(self.y_, n_steps)

        try:
            pred = self.model_.forecast(n_steps)
            return np.asarray(pred, dtype=float).reshape(-1)
        except Exception:
            return fallback_last(self.y_, n_steps)
