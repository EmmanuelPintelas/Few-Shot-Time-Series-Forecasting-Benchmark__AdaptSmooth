from __future__ import annotations

from typing import Dict, Optional
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, is_constant, fallback_last
from models.classical.config import (
    AUTO_ARIMA_MAX_P,
    AUTO_ARIMA_MAX_Q,
    AUTO_ARIMA_MAX_D,
    AUTO_ARIMA_MAX_ORDER,
    AUTO_ARIMA_RESEARCH_EVERY_NEW_POINTS,
    AUTO_ARIMA_UPDATE_MAXITER,
)
from eval_config import RANDOM_SEED

try:
    from pmdarima import auto_arima as pmd_auto_arima
    print("[OK] pmdarima imported successfully")
except Exception as e:
    print("[WARNING] pmdarima import failed:", repr(e))
    pmd_auto_arima = None


class AutoARIMAForecaster(BaseForecaster):
    name = "AutoARIMA"

    def __init__(self):
        self.y_ = np.asarray([], dtype=float)
        self.model_ = None
        self.last_ = 0.0
        self.error_ = None
        self.n_fit_ = 0
        self.last_auto_search_n_ = 0

    def _run_auto_search(self, y: np.ndarray):
        self.model_ = pmd_auto_arima(
            y,
            seasonal=False,
            start_p=0,
            start_q=0,
            max_p=AUTO_ARIMA_MAX_P,
            max_q=AUTO_ARIMA_MAX_Q,
            max_d=AUTO_ARIMA_MAX_D,
            max_order=AUTO_ARIMA_MAX_ORDER,
            information_criterion="aicc",
            stepwise=True,
            suppress_warnings=True,
            error_action="ignore",
            with_intercept="auto",
            random_state=RANDOM_SEED,
        )

        self.n_fit_ = len(y)
        self.last_auto_search_n_ = len(y)
        self.error_ = None

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        y_new = as_1d_float(y)
        self.y_ = y_new
        self.last_ = float(y_new[-1]) if len(y_new) else 0.0

        if pmd_auto_arima is None:
            self.model_ = None
            self.error_ = "pmdarima is not installed"
            return self

        if len(y_new) < 4 or is_constant(y_new):
            self.model_ = None
            self.error_ = "too short or constant"
            self.n_fit_ = len(y_new)
            return self

        needs_full_search = (
            self.model_ is None
            or self.n_fit_ == 0
            or len(y_new) < self.n_fit_
            or (len(y_new) - self.last_auto_search_n_) >= AUTO_ARIMA_RESEARCH_EVERY_NEW_POINTS
        )

        if needs_full_search:
            try:
                self._run_auto_search(y_new)
            except Exception as exc:
                self.model_ = None
                self.error_ = str(exc)
            return self

        if len(y_new) > self.n_fit_:
            new_obs = y_new[self.n_fit_:]

            try:
                self.model_.update(new_obs, maxiter=AUTO_ARIMA_UPDATE_MAXITER)
                self.n_fit_ = len(y_new)
                self.error_ = None
            except Exception as exc:
                try:
                    self._run_auto_search(y_new)
                except Exception:
                    self.error_ = str(exc)

        return self

    def predict(self, n_steps: int) -> np.ndarray:
        if self.model_ is None:
            return fallback_last(self.y_, n_steps)

        try:
            return np.asarray(self.model_.predict(n_periods=n_steps), dtype=float)
        except Exception:
            return fallback_last(self.y_, n_steps)
