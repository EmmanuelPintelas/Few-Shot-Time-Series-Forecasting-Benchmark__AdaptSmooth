from __future__ import annotations

from typing import Dict, Optional
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, fallback_last
from eval_utils import infer_seasonal_period


class NaiveLastValue(BaseForecaster):
    name = "Naive"

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        self.last_ = float(self.y_[-1]) if len(self.y_) else 0.0
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        return np.repeat(self.last_, n_steps)


class DriftForecaster(BaseForecaster):
    name = "Drift"

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        y = as_1d_float(y)
        self.y_ = y
        self.last_ = float(y[-1]) if len(y) else 0.0
        if len(y) < 2:
            self.slope_ = 0.0
        else:
            self.slope_ = float((y[-1] - y[0]) / (len(y) - 1))
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        steps = np.arange(1, n_steps + 1, dtype=float)
        return self.last_ + self.slope_ * steps


class SeasonalNaiveForecaster(BaseForecaster):
    name = "SeasonalNaive"

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        context = context or {}
        self.period_ = context.get("seasonal_period")
        if self.period_ is None:
            self.period_ = infer_seasonal_period(
                context.get("dataset_name", ""),
                context.get("history_ds", None),
            )
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        y = self.y_
        m = self.period_
        if m is None or len(y) < m or m <= 0:
            return fallback_last(y, n_steps)

        preds = []
        for i in range(n_steps):
            idx = len(y) - m + (i % m)
            if 0 <= idx < len(y):
                preds.append(float(y[idx]))
            else:
                preds.append(float(y[-1]))
        return np.asarray(preds, dtype=float)
