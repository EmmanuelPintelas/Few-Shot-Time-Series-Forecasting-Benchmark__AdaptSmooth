from __future__ import annotations

from typing import Dict, Optional
import numpy as np
from statsmodels.tsa.holtwinters import ExponentialSmoothing as HWExponentialSmoothing

from models.base import BaseForecaster
from models.model_utils import as_1d_float, is_constant, fallback_last


class ETSForecaster(BaseForecaster):
    name = "ETS"

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        self.model_ = None
        self.last_ = float(self.y_[-1]) if len(self.y_) else 0.0

        if HWExponentialSmoothing is None or len(self.y_) < 3 or is_constant(self.y_):
            return self

        try:
            trend = "add" if len(self.y_) >= 6 else None
            fit = HWExponentialSmoothing(
                self.y_,
                trend=trend,
                damped_trend=False,
                seasonal=None,
                initialization_method="estimated",
            ).fit(optimized=True)
            self.model_ = fit
        except Exception:
            self.model_ = None
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        if self.model_ is None:
            return fallback_last(self.y_, n_steps)
        try:
            return np.asarray(self.model_.forecast(n_steps), dtype=float)
        except Exception:
            return fallback_last(self.y_, n_steps)
