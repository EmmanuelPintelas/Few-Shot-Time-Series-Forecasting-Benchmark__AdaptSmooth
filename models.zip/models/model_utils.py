"""Utility functions shared by model implementations."""

from __future__ import annotations

from typing import Sequence
import importlib.util
import numpy as np


def has_module(module_name: str) -> bool:
    return importlib.util.find_spec(module_name) is not None


def as_1d_float(y: Sequence[float]) -> np.ndarray:
    arr = np.asarray(y, dtype=float).reshape(-1)
    arr = arr[np.isfinite(arr)]
    return arr


def is_constant(y: np.ndarray, tol: float = 1e-12) -> bool:
    return len(y) == 0 or float(np.nanstd(y)) <= tol


def fallback_last(y: np.ndarray, n_steps: int) -> np.ndarray:
    if len(y) == 0:
        return np.zeros(n_steps, dtype=float)
    return np.repeat(float(y[-1]), n_steps)


def sanitize_predictions(pred: np.ndarray, fallback_value: float, n_steps: int) -> np.ndarray:
    pred = np.asarray(pred, dtype=float).reshape(-1)

    if len(pred) != n_steps:
        fixed = np.repeat(fallback_value, n_steps).astype(float)
        fixed[: min(len(pred), n_steps)] = pred[: min(len(pred), n_steps)]
        pred = fixed

    pred = np.where(np.isfinite(pred), pred, fallback_value)
    return pred.astype(float)
