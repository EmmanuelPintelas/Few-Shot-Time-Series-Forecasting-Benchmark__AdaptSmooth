"""Template custom model configuration.

Copy this folder, rename it, implement your model class, then register its
get_model_specs() provider in models/registry.py.
"""

ENABLED = False
MODEL_NAME = "TemplateModel"
