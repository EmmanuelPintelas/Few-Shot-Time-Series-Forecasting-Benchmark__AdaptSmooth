from __future__ import annotations

from typing import Dict, List, Optional
import numpy as np

from models.base import BaseForecaster
from models.model_utils import as_1d_float, fallback_last
from models.registry_types import ModelSpec
from models.template_model import config


class TemplateModel(BaseForecaster):
    def __init__(self):
        self.name = config.MODEL_NAME
        self.y_ = np.asarray([], dtype=float)

    def fit(self, y: np.ndarray, horizon: int = 1, context: Optional[Dict] = None):
        self.y_ = as_1d_float(y)
        return self

    def predict(self, n_steps: int) -> np.ndarray:
        return fallback_last(self.y_, n_steps)


def get_model_specs() -> List[ModelSpec]:
    if not config.ENABLED:
        return []
    return [ModelSpec(name=config.MODEL_NAME, factory=lambda: TemplateModel())]
