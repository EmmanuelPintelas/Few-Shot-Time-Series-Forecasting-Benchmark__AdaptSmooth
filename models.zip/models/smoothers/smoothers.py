from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from statsmodels.nonparametric.smoothers_lowess import lowess as sm_lowess
except Exception:  # pragma: no cover - optional dependency guard
    sm_lowess = None

try:
    from statsmodels.tsa.statespace.structural import UnobservedComponents
except Exception:  # pragma: no cover - optional dependency guard
    UnobservedComponents = None

from models.model_utils import as_1d_float, is_constant
from models.smoothers.config import DEFAULT_EXP_WINDOW, SMOOTHER_CANDIDATES


# =============================================================================
# Shared numerical helpers
# =============================================================================


def _safe_same_length(z: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Return a finite same-length smoother output, falling back to y where needed."""
    y = as_1d_float(y)
    z = np.asarray(z, dtype=float).reshape(-1)

    if len(z) != len(y):
        return y.copy()

    if len(y) == 0:
        return y.copy()

    finite = np.isfinite(z)
    if finite.all():
        return z.astype(float)

    if finite.any():
        # Fill isolated non-finite values by linear interpolation over valid values.
        idx = np.arange(len(z))
        z_filled = np.interp(idx, idx[finite], z[finite])
        return np.where(np.isfinite(z_filled), z_filled, y)

    return y.copy()


def _window_weights(m: int, kind: str) -> np.ndarray:
    kind = str(kind).lower()
    if kind in {"flat", "ones", "mean", "boxcar"}:
        w = np.ones(m, dtype=float)
    elif kind in {"hanning", "hann"}:
        w = np.hanning(m).astype(float)
    elif kind == "hamming":
        w = np.hamming(m).astype(float)
    elif kind == "bartlett":
        w = np.bartlett(m).astype(float)
    elif kind == "blackman":
        w = np.blackman(m).astype(float)
    else:
        w = np.ones(m, dtype=float)

    s = float(np.sum(w))
    if not np.isfinite(s) or abs(s) < 1e-12:
        w = np.ones(m, dtype=float)
        s = float(np.sum(w))
    return w / s


def _reflect_pad_1d(x: np.ndarray, pad: int) -> np.ndarray:
    if pad <= 0 or len(x) <= 1:
        return x.copy()
    pad = min(int(pad), max(0, len(x) - 1))
    return np.pad(x, (pad, pad), mode="reflect")


def _ols_predict(y: np.ndarray, X: np.ndarray) -> np.ndarray:
    y = as_1d_float(y)
    X = np.asarray(X, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    X1 = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(X1, y, rcond=None)
    return (X1 @ beta).astype(float)


def _moving_average_partial_exp(y: np.ndarray, window: int, alpha: float) -> np.ndarray:
    """Finite-window exponential smoother with safe partial windows at the start."""
    y = as_1d_float(y)
    n = len(y)
    if n == 0:
        return y.copy()

    window = max(1, int(window))
    alpha = min(max(float(alpha), 0.0), 1.0)

    z = np.empty(n, dtype=float)
    for t in range(n):
        start = max(0, t - window + 1)
        vals = y[start:t + 1]
        # Lag weights: current observation gets j=0, previous j=1, etc.
        lags = np.arange(len(vals) - 1, -1, -1, dtype=float)
        weights = (1.0 - alpha) ** lags
        weights = weights / max(float(np.sum(weights)), 1e-12)
        z[t] = float(np.dot(weights, vals))
    return z


def _diff_1(y: np.ndarray) -> np.ndarray:
    y = as_1d_float(y)
    if len(y) <= 1:
        return np.zeros_like(y)
    d = np.empty_like(y)
    d[1:] = y[1:] - y[:-1]
    d[0] = d[1]
    return d


def _reconstruct_from_diff(y: np.ndarray, d_smooth: np.ndarray) -> np.ndarray:
    """Reconstruct a level series from a smoothed first-difference proxy."""
    y = as_1d_float(y)
    d_smooth = _safe_same_length(d_smooth, np.zeros_like(y))
    if len(y) == 0:
        return y.copy()
    z = np.empty_like(y)
    z[0] = y[0]
    if len(y) > 1:
        z[1:] = y[0] + np.cumsum(d_smooth[1:])
    return _safe_same_length(z, y)


# =============================================================================
# Base interface
# =============================================================================


@dataclass(frozen=True)
class Smoother:
    name: str

    def transform(self, y: np.ndarray) -> np.ndarray:
        raise NotImplementedError


# =============================================================================
# Direct level-domain smoothers
# =============================================================================


@dataclass(frozen=True)
class IdentitySmoother(Smoother):
    def __init__(self):
        object.__setattr__(self, "name", "identity")

    def transform(self, y: np.ndarray) -> np.ndarray:
        return as_1d_float(y).copy()


@dataclass(frozen=True)
class FiniteExpSmoother(Smoother):
    """Finite-window exponential smoother from the paper/main-2 catalogue.

    Unlike the old visualization helper, this evaluator-safe version uses
    partial windows at the beginning rather than returning a NaN prefix.
    """

    window: int = 3
    alpha: float = 0.30

    def __init__(self, window: int = DEFAULT_EXP_WINDOW, alpha: float = 0.30, name: Optional[str] = None):
        window = max(1, int(window))
        alpha = min(max(float(alpha), 0.0), 1.0)
        object.__setattr__(self, "window", window)
        object.__setattr__(self, "alpha", alpha)
        if name is None:
            name = f"exp_m_{window}_alpha_{alpha:.2f}"
        object.__setattr__(self, "name", name)

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) == 0 or is_constant(y):
            return y.copy()
        return _safe_same_length(_moving_average_partial_exp(y, self.window, self.alpha), y)


@dataclass(frozen=True)
class EWMSmoother(Smoother):
    """Recursive EWMA retained for backward compatibility/ablation."""

    alpha: float = 0.30

    def __init__(self, alpha: float = 0.30):
        alpha = min(max(float(alpha), 0.0), 1.0)
        object.__setattr__(self, "alpha", alpha)
        object.__setattr__(self, "name", f"ewm_alpha_{alpha:.2f}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) == 0 or is_constant(y):
            return y.copy()
        z = pd.Series(y).ewm(alpha=self.alpha, adjust=False).mean().to_numpy(dtype=float)
        return _safe_same_length(z, y)


# Backward-compatible class name used by existing model folders.
class ExpSmoother(FiniteExpSmoother):
    def __init__(self, alpha: float = 0.30, window: int = DEFAULT_EXP_WINDOW):
        # Preserve old name format so existing result paths/configs remain stable.
        super().__init__(window=window, alpha=alpha, name=f"exp_alpha_{float(alpha):.2f}")


@dataclass(frozen=True)
class ConvSmoother(Smoother):
    window: int = 5
    kind: str = "flat"

    def __init__(self, window: int = 5, kind: str = "flat"):
        window = int(window)
        if window < 3:
            window = 3
        if window % 2 == 0:
            window += 1
        kind = str(kind).lower()
        if kind in {"ones", "mean", "boxcar"}:
            kind = "flat"
        object.__setattr__(self, "window", window)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "name", f"conv_{window}_{kind}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < 3 or is_constant(y):
            return y.copy()

        m = min(self.window, len(y))
        if m % 2 == 0:
            m -= 1
        if m < 3:
            return y.copy()

        w = _window_weights(m, self.kind)
        pad = m // 2
        y_pad = _reflect_pad_1d(y, pad)
        z = np.convolve(y_pad, w[::-1], mode="valid")
        return _safe_same_length(z, y)


@dataclass(frozen=True)
class FFTLowPassSmoother(Smoother):
    cutoff: float = 0.25
    pad: int = 10

    def __init__(self, cutoff: float = 0.25, pad: int = 10):
        cutoff = min(max(float(cutoff), 0.01), 1.0)
        pad = max(0, int(pad))
        object.__setattr__(self, "cutoff", cutoff)
        object.__setattr__(self, "pad", pad)
        object.__setattr__(self, "name", f"fft_cutoff_{cutoff:.2f}_pad_{pad}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < 8 or is_constant(y):
            return y.copy()
        try:
            pad = min(self.pad, max(0, len(y) - 1))
            y_pad = _reflect_pad_1d(y, pad)
            coeff = np.fft.rfft(y_pad)
            k_keep = max(1, min(len(coeff), int(np.floor(self.cutoff * len(coeff)))))
            coeff[k_keep:] = 0.0
            z_pad = np.fft.irfft(coeff, n=len(y_pad))
            z = z_pad[pad:pad + len(y)] if pad > 0 else z_pad
            return _safe_same_length(z, y)
        except Exception:
            return y.copy()


@dataclass(frozen=True)
class PolynomialTrendSmoother(Smoother):
    degree: int = 1

    def __init__(self, degree: int = 1):
        degree = max(1, min(int(degree), 5))
        object.__setattr__(self, "degree", degree)
        object.__setattr__(self, "name", f"poly_degree_{degree}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < self.degree + 3 or is_constant(y):
            return y.copy()
        try:
            x = np.linspace(0.0, 1.0, len(y))
            X = np.column_stack([x ** d for d in range(1, self.degree + 1)])
            return _safe_same_length(_ols_predict(y, X), y)
        except Exception:
            return y.copy()


@dataclass(frozen=True)
class SplineSmoother(Smoother):
    kind: str = "natural"
    knots: int = 6

    def __init__(self, kind: str = "natural", knots: int = 6):
        kind = str(kind).lower()
        if kind not in {"linear", "cubic", "natural"}:
            kind = "natural"
        knots = max(1, int(knots))
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "knots", knots)
        object.__setattr__(self, "name", f"spline_{kind}_k_{knots}")

    def _basis(self, n: int) -> np.ndarray:
        x = np.linspace(0.0, 1.0, n)
        knots = np.linspace(0.0, 1.0, self.knots + 2)[1:-1]

        if self.kind == "linear":
            cols = [x] + [np.maximum(0.0, x - k) for k in knots]
            return np.column_stack(cols)

        if self.kind == "cubic":
            cols = [x, x ** 2, x ** 3] + [np.maximum(0.0, x - k) ** 3 for k in knots]
            return np.column_stack(cols)

        # Natural cubic spline.  Needs at least 3 knots; fall back to linear if too few.
        if len(knots) < 3:
            cols = [x] + [np.maximum(0.0, x - k) for k in knots]
            return np.column_stack(cols)

        kK = knots[-1]
        kKm1 = knots[-2]

        def tp3(xx: np.ndarray, kk: float) -> np.ndarray:
            return np.maximum(0.0, xx - kk) ** 3

        hs = []
        for kj in knots[:-2]:
            h = (tp3(x, kj) - tp3(x, kK)) / max(kK - kj, 1e-12)
            h -= (tp3(x, kKm1) - tp3(x, kK)) / max(kK - kKm1, 1e-12)
            hs.append(h)
        return np.column_stack([x] + hs)

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        min_n = max(6, min(self.knots + 3, 12))
        if len(y) < min_n or is_constant(y):
            return y.copy()
        try:
            X = self._basis(len(y))
            return _safe_same_length(_ols_predict(y, X), y)
        except Exception:
            return y.copy()


@dataclass(frozen=True)
class GaussianRBFSmoother(Smoother):
    centers: int = 8
    sigma: float = 0.10

    def __init__(self, centers: int = 8, sigma: float = 0.10):
        centers = max(2, int(centers))
        sigma = max(float(sigma), 1e-4)
        object.__setattr__(self, "centers", centers)
        object.__setattr__(self, "sigma", sigma)
        object.__setattr__(self, "name", f"gauss_rbf_k_{centers}_sigma_{sigma:.2f}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < max(8, self.centers // 2) or is_constant(y):
            return y.copy()
        try:
            x = np.linspace(0.0, 1.0, len(y))
            centers = np.linspace(0.0, 1.0, self.centers)
            X = np.column_stack([np.exp(-0.5 * ((x - c) / self.sigma) ** 2) for c in centers])
            return _safe_same_length(_ols_predict(y, X), y)
        except Exception:
            return y.copy()


@dataclass(frozen=True)
class BinnerSmoother(Smoother):
    bins: int = 6

    def __init__(self, bins: int = 6):
        bins = max(1, int(bins))
        object.__setattr__(self, "bins", bins)
        object.__setattr__(self, "name", f"binner_k_{bins}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < max(5, self.bins + 1) or is_constant(y):
            return y.copy()
        try:
            x = np.linspace(0.0, 1.0, len(y))
            cuts = np.linspace(0.0, 1.0, self.bins + 2)[1:-1]
            bin_ids = np.digitize(x, cuts, right=True)
            X_full = np.eye(self.bins + 1)[bin_ids]
            X = X_full[:, :-1]  # avoid collinearity with intercept
            return _safe_same_length(_ols_predict(y, X), y)
        except Exception:
            return y.copy()


@dataclass(frozen=True)
class LowessSmoother(Smoother):
    frac: float = 0.30
    iterations: int = 1

    def __init__(self, frac: float = 0.30, iterations: int = 1):
        frac = min(max(float(frac), 0.02), 1.0)
        iterations = max(0, int(iterations))
        object.__setattr__(self, "frac", frac)
        object.__setattr__(self, "iterations", iterations)
        object.__setattr__(self, "name", f"lowess_frac_{frac:.2f}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < 5 or is_constant(y):
            return y.copy()
        try:
            if sm_lowess is not None:
                x = np.arange(len(y), dtype=float)
                z = sm_lowess(y, x, frac=self.frac, it=self.iterations, return_sorted=False)
                return _safe_same_length(z, y)
            return _safe_same_length(_manual_lowess(y, self.frac, max(1, self.iterations)), y)
        except Exception:
            return y.copy()


# Manual LOWESS fallback ported from main-2.
def _manual_lowess(y: np.ndarray, frac: float, iterations: int = 1) -> np.ndarray:
    y = as_1d_float(y)
    n = len(y)
    x = np.linspace(0.0, 1.0, n)
    r = max(2, min(int(np.ceil(frac * n)), n))
    yhat = np.zeros(n, dtype=float)
    robust_w = np.ones(n, dtype=float)

    for _ in range(max(1, iterations)):
        X = np.column_stack([np.ones(n), x])
        for t in range(n):
            d = np.abs(x - x[t])
            idx = np.argpartition(d, r - 1)[:r]
            h = float(np.max(d[idx]))
            if h <= 1e-12:
                yhat[t] = y[t]
                continue
            w = (1.0 - (d / h) ** 3) ** 3
            w[d > h] = 0.0
            w *= robust_w
            XtW = X.T * w
            XtWX = XtW @ X
            XtWy = XtW @ y
            try:
                beta = np.linalg.solve(XtWX, XtWy)
                yhat[t] = beta[0] + beta[1] * x[t]
            except Exception:
                ww = np.maximum(w, 1e-12)
                yhat[t] = np.average(y, weights=ww)

        if iterations > 1:
            resid = y - yhat
            s = np.median(np.abs(resid)) + 1e-12
            u = resid / (6.0 * s)
            robust_w = (1.0 - u * u) ** 2
            robust_w[np.abs(u) >= 1.0] = 0.0
    return yhat


@dataclass(frozen=True)
class DecomposeAdditiveSmoother(Smoother):
    trend_name: str = "conv"
    period: int = 24
    trend_window: int = 7
    trend_kind: str = "flat"
    trend_frac: float = 0.20
    trend_knots: int = 6

    def __init__(
        self,
        trend_name: str = "conv",
        period: int = 24,
        trend_window: int = 7,
        trend_kind: str = "flat",
        trend_frac: float = 0.20,
        trend_knots: int = 6,
    ):
        trend_name = str(trend_name).lower()
        period = max(2, int(period))
        object.__setattr__(self, "trend_name", trend_name)
        object.__setattr__(self, "period", period)
        object.__setattr__(self, "trend_window", int(trend_window))
        object.__setattr__(self, "trend_kind", str(trend_kind).lower())
        object.__setattr__(self, "trend_frac", float(trend_frac))
        object.__setattr__(self, "trend_knots", int(trend_knots))

        if trend_name == "conv":
            name = f"decomp_add_conv_{int(trend_window)}_{str(trend_kind).lower()}_period_{period}"
        elif trend_name == "lowess":
            name = f"decomp_add_lowess_{float(trend_frac):.2f}_period_{period}"
        elif trend_name in {"spline", "spline_natural", "natural"}:
            name = f"decomp_add_spline_natural_{int(trend_knots)}_period_{period}"
        else:
            name = f"decomp_add_conv_{int(trend_window)}_{str(trend_kind).lower()}_period_{period}"
        object.__setattr__(self, "name", name)

    def _trend(self, y: np.ndarray) -> np.ndarray:
        if self.trend_name == "lowess":
            return LowessSmoother(frac=self.trend_frac).transform(y)
        if self.trend_name in {"spline", "spline_natural", "natural"}:
            return SplineSmoother(kind="natural", knots=self.trend_knots).transform(y)
        return ConvSmoother(window=self.trend_window, kind=self.trend_kind).transform(y)

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < 8 or is_constant(y):
            return y.copy()
        try:
            trend = self._trend(y)
            trend = _safe_same_length(trend, y)
            p = int(self.period)
            if len(y) < 2 * p:
                # With less than two cycles, seasonal phase means are unstable.
                return trend

            residual = y - trend
            phase_means = np.zeros(p, dtype=float)
            phase_counts = np.zeros(p, dtype=int)
            for t, r in enumerate(residual):
                j = t % p
                phase_means[j] += r
                phase_counts[j] += 1
            valid = phase_counts > 0
            phase_means[valid] /= phase_counts[valid]
            phase_means[~valid] = 0.0
            phase_means -= np.mean(phase_means[valid]) if np.any(valid) else 0.0
            seasonal = np.asarray([phase_means[t % p] for t in range(len(y))], dtype=float)
            return _safe_same_length(trend + seasonal, y)
        except Exception:
            return y.copy()


# =============================================================================
# Kalman smoothers, ported from main-2 and kept dependency-light
# =============================================================================


def _kalman_rts_smoother(
    y: np.ndarray,
    A: np.ndarray,
    H: np.ndarray,
    Q: np.ndarray,
    R: np.ndarray,
    x0: np.ndarray,
    P0: np.ndarray,
) -> np.ndarray:
    y = as_1d_float(y)
    T = len(y)
    n = A.shape[0]
    if T == 0:
        return y.copy()

    x_pred = np.zeros((T, n), dtype=float)
    P_pred = np.zeros((T, n, n), dtype=float)
    x_filt = np.zeros((T, n), dtype=float)
    P_filt = np.zeros((T, n, n), dtype=float)

    x_prev = x0.astype(float)
    P_prev = P0.astype(float)

    eye = np.eye(n)
    for t in range(T):
        xp = A @ x_prev
        Pp = A @ P_prev @ A.T + Q
        S = H @ Pp @ H.T + R
        try:
            K = Pp @ H.T @ np.linalg.pinv(S)
        except Exception:
            return y.copy()
        innov = np.array([y[t]], dtype=float) - (H @ xp).reshape(1)
        xf = xp + (K @ innov).reshape(n)
        Pf = (eye - K @ H) @ Pp
        x_pred[t], P_pred[t] = xp, Pp
        x_filt[t], P_filt[t] = xf, Pf
        x_prev, P_prev = xf, Pf

    x_smooth = np.zeros_like(x_filt)
    x_smooth[-1] = x_filt[-1]

    for t in range(T - 2, -1, -1):
        C = P_filt[t] @ A.T @ np.linalg.pinv(P_pred[t + 1])
        x_smooth[t] = x_filt[t] + C @ (x_smooth[t + 1] - x_pred[t + 1])

    return (H @ x_smooth.T).reshape(-1).astype(float)


@dataclass(frozen=True)
class KalmanLevelSmoother(Smoother):
    q_level: float = 0.10
    sigma2: float = 1.00

    def __init__(self, q_level: float = 0.10, sigma2: float = 1.00):
        object.__setattr__(self, "q_level", max(float(q_level), 1e-8))
        object.__setattr__(self, "sigma2", max(float(sigma2), 1e-8))
        object.__setattr__(self, "name", f"kalman_level_q_{float(q_level):.2f}_sigma_{float(sigma2):.2f}")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < 4 or is_constant(y):
            return y.copy()
        try:
            A = np.array([[1.0]])
            H = np.array([[1.0]])
            Q = np.array([[self.q_level]])
            R = np.array([[self.sigma2]])
            x0 = np.array([y[0]])
            P0 = np.array([[10.0]])
            return _safe_same_length(_kalman_rts_smoother(y, A, H, Q, R, x0, P0), y)
        except Exception:
            return y.copy()


@dataclass(frozen=True)
class KalmanLevelTrendSmoother(Smoother):
    q_level: float = 0.10
    q_trend: float = 0.10
    sigma2: float = 1.00
    alias_name: Optional[str] = None

    def __init__(self, q_level: float = 0.10, q_trend: float = 0.10, sigma2: float = 1.00, alias_name: Optional[str] = None):
        object.__setattr__(self, "q_level", max(float(q_level), 1e-8))
        object.__setattr__(self, "q_trend", max(float(q_trend), 1e-8))
        object.__setattr__(self, "sigma2", max(float(sigma2), 1e-8))
        object.__setattr__(self, "alias_name", alias_name)
        name = alias_name or f"kalman_level_trend_q_{float(q_level):.2f}_qtrend_{float(q_trend):.2f}_sigma_{float(sigma2):.2f}"
        object.__setattr__(self, "name", name)

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < 5 or is_constant(y):
            return y.copy()
        try:
            A = np.array([[1.0, 1.0], [0.0, 1.0]])
            H = np.array([[1.0, 0.0]])
            Q = np.diag([self.q_level, self.q_trend])
            R = np.array([[self.sigma2]])
            x0 = np.array([y[0], 0.0])
            P0 = np.diag([10.0, 10.0])
            return _safe_same_length(_kalman_rts_smoother(y, A, H, Q, R, x0, P0), y)
        except Exception:
            return y.copy()


@dataclass(frozen=True)
class StatsmodelsKalmanLocalLinearSmoother(Smoother):
    """Optional statsmodels local-linear trend smoother retained for experiments."""

    def __init__(self):
        object.__setattr__(self, "name", "kalman_statsmodels_local_linear")

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) < 6 or UnobservedComponents is None or is_constant(y):
            return y.copy()
        try:
            mod = UnobservedComponents(y, level="local linear trend")
            res = mod.fit(disp=False, maxiter=100)
            z = np.asarray(res.smoothed_state[0], dtype=float)
            return _safe_same_length(z, y)
        except Exception:
            return y.copy()


# Backward-compatible class name used by existing imports.
class KalmanLocalLinearSmoother(KalmanLevelTrendSmoother):
    def __init__(self):
        super().__init__(q_level=0.10, q_trend=0.10, sigma2=1.00, alias_name="kalman_local_linear")


# =============================================================================
# Difference-domain, reconstructed-level smoothers
# =============================================================================


@dataclass(frozen=True)
class DiffReconstructionSmoother(Smoother):
    """Use first differences as the smoothed signal, then reconstruct levels."""

    inner: Optional[Smoother] = None

    def __init__(self, inner: Optional[Smoother] = None, name: Optional[str] = None):
        object.__setattr__(self, "inner", inner)
        if name is None:
            if inner is None:
                name = "diff_reconstruct"
            else:
                name = f"diff_{inner.name}"
        object.__setattr__(self, "name", name)

    def transform(self, y: np.ndarray) -> np.ndarray:
        y = as_1d_float(y)
        if len(y) <= 1:
            return y.copy()
        d = _diff_1(y)
        if self.inner is None:
            d_smooth = d
        else:
            d_smooth = self.inner.transform(d)
        return _reconstruct_from_diff(y, d_smooth)


# =============================================================================
# Factory
# =============================================================================


def _parse_float_after(parts: Sequence[str], key: str) -> float:
    idx = list(parts).index(key)
    return float(parts[idx + 1])


def _parse_int_after(parts: Sequence[str], key: str) -> int:
    idx = list(parts).index(key)
    return int(parts[idx + 1])


def make_smoother(name: str) -> Smoother:
    """Create a smoother from a configuration name.

    Supported examples:
        identity
        exp_alpha_0.30
        exp_m_3_alpha_0.20
        ewm_alpha_0.30
        conv_7_hanning
        fft_cutoff_0.25_pad_10
        poly_degree_2
        spline_natural_k_6
        gauss_rbf_k_8_sigma_0.10
        binner_k_6
        lowess_frac_0.30
        decomp_add_conv_7_flat_period_24
        kalman_level_trend_q_0.10_qtrend_0.10_sigma_1.00
        diff_lowess_frac_0.20
    """
    name = str(name)
    parts = name.split("_")

    if name == "identity":
        return IdentitySmoother()

    # Difference-domain names are parsed first and wrapped in reconstruction.
    if name == "diff_reconstruct":
        return DiffReconstructionSmoother()

    if name.startswith("diff_"):
        inner_name = name[len("diff_"):]
        inner = make_smoother(inner_name)
        # Canonical names for common old Δ variants.
        return DiffReconstructionSmoother(inner=inner, name=name)

    # Backward-compatible finite exponential name.
    if name.startswith("exp_alpha_"):
        alpha = float(parts[-1])
        return ExpSmoother(alpha=alpha, window=DEFAULT_EXP_WINDOW)

    if name.startswith("exp_m_"):
        window = _parse_int_after(parts, "m")
        alpha = _parse_float_after(parts, "alpha")
        return FiniteExpSmoother(window=window, alpha=alpha)

    if name.startswith("ewm_alpha_"):
        return EWMSmoother(alpha=float(parts[-1]))

    if name.startswith("conv_"):
        window = int(parts[1])
        kind = "_".join(parts[2:])
        return ConvSmoother(window=window, kind=kind)

    if name.startswith("fft_cutoff_"):
        cutoff = _parse_float_after(parts, "cutoff")
        pad = _parse_int_after(parts, "pad")
        return FFTLowPassSmoother(cutoff=cutoff, pad=pad)

    if name.startswith("poly_degree_"):
        degree = int(parts[-1])
        return PolynomialTrendSmoother(degree=degree)

    if name.startswith("spline_"):
        kind = parts[1]
        knots = _parse_int_after(parts, "k")
        return SplineSmoother(kind=kind, knots=knots)

    if name.startswith("gauss_rbf_"):
        centers = _parse_int_after(parts, "k")
        sigma = _parse_float_after(parts, "sigma")
        return GaussianRBFSmoother(centers=centers, sigma=sigma)

    if name.startswith("binner_k_"):
        return BinnerSmoother(bins=int(parts[-1]))

    if name.startswith("lowess_frac_"):
        frac = float(parts[-1])
        return LowessSmoother(frac=frac)

    if name.startswith("decomp_add_"):
        period = _parse_int_after(parts, "period")
        if parts[2] == "conv":
            trend_window = int(parts[3])
            trend_kind = parts[4]
            return DecomposeAdditiveSmoother(
                trend_name="conv",
                period=period,
                trend_window=trend_window,
                trend_kind=trend_kind,
            )
        if parts[2] == "lowess":
            trend_frac = float(parts[3])
            return DecomposeAdditiveSmoother(
                trend_name="lowess",
                period=period,
                trend_frac=trend_frac,
            )
        if parts[2] == "spline" and parts[3] == "natural":
            trend_knots = int(parts[4])
            return DecomposeAdditiveSmoother(
                trend_name="spline_natural",
                period=period,
                trend_knots=trend_knots,
            )

    if name == "kalman_local_linear":
        return KalmanLocalLinearSmoother()

    if name == "kalman_statsmodels_local_linear":
        return StatsmodelsKalmanLocalLinearSmoother()

    if name.startswith("kalman_level_trend_"):
        q_level = _parse_float_after(parts, "q")
        q_trend = _parse_float_after(parts, "qtrend")
        sigma2 = _parse_float_after(parts, "sigma")
        return KalmanLevelTrendSmoother(q_level=q_level, q_trend=q_trend, sigma2=sigma2)

    if name.startswith("kalman_level_"):
        q_level = _parse_float_after(parts, "q")
        sigma2 = _parse_float_after(parts, "sigma")
        return KalmanLevelSmoother(q_level=q_level, sigma2=sigma2)

    raise ValueError(f"Unknown smoother: {name}")


def get_smoother_candidates(names: List[str] | None = None) -> List[Smoother]:
    names = SMOOTHER_CANDIDATES if names is None else names
    return [make_smoother(name) for name in names]


def available_smoother_names() -> List[str]:
    return list(SMOOTHER_CANDIDATES)
