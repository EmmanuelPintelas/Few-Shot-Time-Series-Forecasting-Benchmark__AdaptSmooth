"""Configuration for smoothing transformations.

This module is intentionally model-independent.  It defines the candidate pool
used by support-selected smoothers and by future AdaptSmooth competitors.
Names are parsed by ``models.smoothers.smoothers.make_smoother``.
"""

# Compatibility/defaults -----------------------------------------------------
# ``exp_alpha_0.30`` is interpreted as finite-window exponential smoothing with
# this default window, matching the paper/main-2 operator family more closely
# than pandas recursive EWM.  The old recursive implementation is still
# available through ``ewm_alpha_0.30``.
DEFAULT_EXP_WINDOW = 3

# Full transform pool --------------------------------------------------------
# All transforms return a finite vector with the same length as the input, so
# they can safely be used by generic forecasting wrappers.
SMOOTHER_CANDIDATES_FULL = [
    # Identity / no smoothing.
    "identity",

    # Finite-window exponential smoothers.
    "exp_m_3_alpha_0.20",
    "exp_m_3_alpha_0.40",
    "exp_m_3_alpha_0.60",
    # Backward-compatible names used by earlier experiments.
    "exp_alpha_0.15",
    "exp_alpha_0.30",
    "exp_alpha_0.60",

    # Optional recursive EWMA version from the previous modular implementation.
    "ewm_alpha_0.30",

    # Windowed convolution / FIR smoothers.
    "conv_5_flat",
    "conv_5_hanning",
    "conv_5_hamming",
    "conv_5_bartlett",
    "conv_5_blackman",
    "conv_7_hanning",
    "conv_9_flat",
    "conv_9_hamming",

    # Spectral low-pass smoothers.
    "fft_cutoff_0.05_pad_10",
    "fft_cutoff_0.10_pad_10",
    "fft_cutoff_0.15_pad_10",
    "fft_cutoff_0.20_pad_10",
    "fft_cutoff_0.25_pad_10",

    # Regression trend smoothers.
    "poly_degree_1",
    "poly_degree_2",
    "poly_degree_3",
    "spline_linear_k_6",
    "spline_cubic_k_6",
    "spline_natural_k_6",
    "gauss_rbf_k_8_sigma_0.03",
    "gauss_rbf_k_8_sigma_0.10",
    "binner_k_6",
    "binner_k_10",

    # LOWESS.
    "lowess_frac_0.20",
    "lowess_frac_0.30",

    # Additive decomposition smoothers with fixed daily period proxy.
    "decomp_add_conv_7_flat_period_24",
    "decomp_add_lowess_0.20_period_24",
    "decomp_add_spline_natural_6_period_24",

    # Kalman / state-space smoothers.
    "kalman_level_q_0.10_sigma_1.00",
    "kalman_level_trend_q_0.10_qtrend_0.10_sigma_1.00",
    # Backward-compatible alias for the local-linear trend state-space smoother.
    "kalman_local_linear",

    # Difference-domain smoothers reconstructed back to level scale.
    # These are safe for generic forecasters because they output levels, not raw
    # differences.  They capture the old ΔU-family idea without requiring a
    # special inverse-transform wrapper.
    "diff_reconstruct",
    "diff_exp_m_3_alpha_0.20",
    "diff_exp_m_3_alpha_0.40",
    "diff_exp_m_3_alpha_0.60",
    "diff_lowess_frac_0.20",
    "diff_lowess_frac_0.30",
    "diff_kalman_level_q_0.10_sigma_1.00",
    "diff_kalman_level_trend_q_0.10_qtrend_0.10_sigma_1.00",
]

# A smaller pool is useful while debugging.  Switch SMOOTHER_CANDIDATES to this
# if the full support-selection run is too slow.
SMOOTHER_CANDIDATES_FAST = [
    "identity",
    "exp_alpha_0.30",
    "conv_7_hanning",
    "fft_cutoff_0.25_pad_10",
    "poly_degree_2",
    "lowess_frac_0.30",
    "kalman_local_linear",
]

# Active pool.
SMOOTHER_CANDIDATES = SMOOTHER_CANDIDATES_FULL

# Number of internal rolling origins used for support-only smoother selection.
SUPPORT_SELECTION_MAX_ORIGINS = 4
